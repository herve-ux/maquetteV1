'use client';

import { useState, useRef, DragEvent } from 'react';
import { DocumentItem } from '@/lib/types';
import { getDocumentHelp } from '@/lib/documentHelp';

interface DocumentSlotProps {
  document: DocumentItem;
  index: number;
  onUpload: (docId: string, fileName: string, fileUrl: string) => void;
  onPreview?: (doc: DocumentItem) => void;
  onReset?: (docId: string) => void;
}

export default function DocumentSlot({
  document: doc,
  index,
  onUpload,
  onPreview,
  onReset,
}: DocumentSlotProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const helpTimeoutRef = useRef<ReturnType<typeof setTimeout>>(null);

  const handleFile = async (file: File) => {
    setIsUploading(true);
    const url = URL.createObjectURL(file);
    await new Promise((r) => setTimeout(r, 800 + Math.random() * 400));
    onUpload(doc.id, file.name, url);
    setIsUploading(false);
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const handleDragOver = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  const needsAction = doc.status === 'missing' || doc.status === 'rejected';
  const isDone = doc.status === 'validated';
  const hasFile = !!doc.fileName && !needsAction;

  const help = needsAction ? getDocumentHelp(doc.name) : null;

  const handleMouseEnter = () => {
    if (!help) return;
    helpTimeoutRef.current = setTimeout(() => setShowHelp(true), 300);
  };

  const handleMouseLeave = () => {
    if (helpTimeoutRef.current) clearTimeout(helpTimeoutRef.current);
    setShowHelp(false);
  };

  const handleCardClick = () => {
    if (hasFile && onPreview) onPreview(doc);
  };

  return (
    <div
      className="doc-enter group"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <div
        className={`
          relative rounded-xl border px-4 py-3 transition-all duration-300
          ${
            isDragging
              ? 'border-accent-dark bg-accent-50 scale-[1.01]'
              : needsAction
              ? 'border-neutral-200 bg-white hover:border-neutral-300'
              : isDone
              ? 'border-neutral-100/60 bg-neutral-50/30'
              : 'border-neutral-100 bg-neutral-50/50'
          }
          ${hasFile ? 'cursor-pointer hover:border-neutral-300' : ''}
        `}
        style={isDone ? { opacity: 0.45 } : undefined}
        onClick={handleCardClick}
        onDrop={needsAction ? handleDrop : undefined}
        onDragOver={needsAction ? handleDragOver : undefined}
        onDragLeave={() => setIsDragging(false)}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        <div className="flex items-start justify-between gap-4">
          {/* Left: Doc info */}
          <div className="flex items-start gap-3 min-w-0">
            {/* Status icon */}
            <div className="mt-0.5 flex-shrink-0">
              {doc.status === 'validated' && (
                <div className="w-6 h-6 rounded-full bg-black flex items-center justify-center">
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-white">
                    <path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              )}
              {doc.status === 'uploaded' && (
                <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center">
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-black">
                    <path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              )}
              {doc.status === 'reviewing' && (
                <div className="w-6 h-6 rounded-full bg-accent animate-pulse-soft flex items-center justify-center">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-black/50">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                </div>
              )}
              {doc.status === 'missing' && (
                <div className="w-6 h-6 rounded-full bg-red-50 flex items-center justify-center">
                  <div className="w-2 h-0.5 bg-red-400 rounded-sm" />
                </div>
              )}
              {doc.status === 'rejected' && (
                <div className="w-6 h-6 rounded-full bg-red-50 flex items-center justify-center">
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-red-500">
                    <path d="M6 3.5V6.5M6 8.5V8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                  </svg>
                </div>
              )}
            </div>

            {/* Doc details */}
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <p className={`text-sm font-semibold leading-tight ${needsAction ? 'text-black' : 'text-neutral-600'}`}>
                  {doc.name}
                </p>
                {help && (
                  <button
                    type="button"
                    onClick={(e) => { e.stopPropagation(); setShowHelp(!showHelp); }}
                    className="flex-shrink-0 w-4 h-4 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center transition-colors"
                    aria-label="Aide pour trouver ce document"
                  >
                    <svg width="8" height="8" viewBox="0 0 8 8" fill="none" className="text-neutral-400">
                      <path d="M3 2.5C3 2.22 3.22 2 3.5 2H4.5C4.78 2 5 2.22 5 2.5C5 2.78 4.78 3 4.5 3H4.2V4.5" stroke="currentColor" strokeWidth="0.8" strokeLinecap="round" />
                      <circle cx="4" cy="5.8" r="0.5" fill="currentColor" />
                    </svg>
                  </button>
                )}
              </div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <p className="text-xs text-neutral-400">
                  {doc.person}
                  {doc.date && ` · ${doc.date}`}
                </p>
                {hasFile && (
                  <span className="text-xs text-neutral-300">· Voir</span>
                )}
              </div>

              {doc.status === 'rejected' && doc.rejectionReason && (
                <p className="text-xs text-red-500 mt-1.5 leading-relaxed">{doc.rejectionReason}</p>
              )}
            </div>
          </div>

          {/* Right: Action */}
          <div className="flex-shrink-0" onClick={(e) => e.stopPropagation()}>
            {isUploading ? (
              <div className="flex items-center gap-2 text-xs text-neutral-400">
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2.5" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Envoi...
              </div>
            ) : doc.status === 'missing' ? (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="h-9 px-4 bg-black text-white text-xs font-semibold rounded-lg
                           hover:bg-neutral-800 active:scale-95 transition-all duration-150"
              >
                Déposer
              </button>
            ) : doc.status === 'rejected' ? (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="h-9 px-4 bg-white text-black text-xs font-semibold rounded-lg
                           border border-neutral-200 hover:border-neutral-400
                           active:scale-95 transition-all duration-150"
              >
                Remplacer
              </button>
            ) : doc.status === 'validated' ? (
              <span className="text-xs font-medium text-neutral-400 bg-neutral-100 px-2.5 py-1 rounded-full">Validé</span>
            ) : doc.status === 'uploaded' ? (
              <span className="text-xs font-medium text-black/50 bg-accent-50 px-2.5 py-1 rounded-full">Déposé</span>
            ) : doc.status === 'reviewing' ? (
              <span className="text-xs font-medium text-black/50 bg-accent-50 px-2.5 py-1 rounded-full animate-pulse-soft">En vérification</span>
            ) : null}
          </div>
        </div>

        {/* Help tooltip */}
        {showHelp && help && (
          <div
            className="mt-3 pt-3 border-t border-neutral-100 animate-fadeIn"
            onClick={(e) => e.stopPropagation()}
            onMouseEnter={() => { if (helpTimeoutRef.current) clearTimeout(helpTimeoutRef.current); }}
            onMouseLeave={handleMouseLeave}
          >
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs text-neutral-500 leading-relaxed">{help.tip}</p>
              {help.source && (
                <a
                  href={help.source.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-neutral-100
                             bg-neutral-50 hover:bg-white hover:border-neutral-200 transition-all duration-150
                             text-xs text-neutral-600 hover:text-black group"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={help.source.favicon}
                    alt=""
                    width={14}
                    height={14}
                    className="rounded-sm"
                  />
                  <span className="font-medium">{help.source.label}</span>
                  <svg width="10" height="10" viewBox="0 0 10 10" fill="none" className="text-neutral-300 group-hover:text-neutral-500 transition-colors">
                    <path d="M3 1.5H8.5V7M8.5 1.5L1.5 8.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </a>
              )}
            </div>
          </div>
        )}

        {needsAction && (
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.jpg,.jpeg,.png"
            onChange={handleFileSelect}
            className="hidden"
          />
        )}

        {isDragging && needsAction && (
          <div className="absolute inset-0 rounded-2xl bg-accent-50/80 border-2 border-dashed border-accent-dark flex items-center justify-center pointer-events-none">
            <p className="text-sm font-semibold text-black/60">Déposez votre fichier</p>
          </div>
        )}
      </div>
    </div>
  );
}
