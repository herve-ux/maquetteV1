export interface DocumentSource {
  label: string;
  url: string;
  favicon: string;
}

export interface DocumentHelp {
  tip: string;
  source?: DocumentSource;
}

const documentHelpMap: Record<string, DocumentHelp> = {
  // ── Identité ──
  'cni': {
    tip: 'Recto et verso, en cours de validité.',
    source: {
      label: 'Service-Public.fr',
      url: 'https://www.service-public.fr/particuliers/vosdroits/N358',
      favicon: 'https://www.google.com/s2/favicons?domain=service-public.fr&sz=32',
    },
  },
  'passeport': {
    tip: 'Pages 2 et 3 (photo et informations), en cours de validité.',
    source: {
      label: 'Service-Public.fr',
      url: 'https://www.service-public.fr/particuliers/vosdroits/N360',
      favicon: 'https://www.google.com/s2/favicons?domain=service-public.fr&sz=32',
    },
  },
  'titre de séjour': {
    tip: 'Recto et verso, en cours de validité.',
  },
  'permis de conduire': {
    tip: 'Recto et verso, en cours de validité.',
  },

  // ── État civil ──
  'acte de mariage': {
    tip: 'Copie intégrale de moins de 3 mois.',
    source: {
      label: 'Service-Public.fr',
      url: 'https://www.service-public.fr/particuliers/vosdroits/F1432',
      favicon: 'https://www.google.com/s2/favicons?domain=service-public.fr&sz=32',
    },
  },
  'livret de famille': {
    tip: 'Toutes les pages remplies.',
    source: {
      label: 'Service-Public.fr',
      url: 'https://www.service-public.fr/particuliers/vosdroits/F1345',
      favicon: 'https://www.google.com/s2/favicons?domain=service-public.fr&sz=32',
    },
  },
  'acte de naissance': {
    tip: 'Copie intégrale de moins de 3 mois.',
    source: {
      label: 'Service-Public.fr',
      url: 'https://www.service-public.fr/particuliers/vosdroits/F1427',
      favicon: 'https://www.google.com/s2/favicons?domain=service-public.fr&sz=32',
    },
  },
  'jugement de divorce': {
    tip: 'Copie du jugement définitif.',
  },

  // ── Résidence ──
  'justificatif de domicile': {
    tip: 'Facture de moins de 3 mois : électricité, gaz, eau, internet ou téléphone.',
  },
  'bail de location': {
    tip: 'Copie complète du bail signé.',
  },
  'attestation hébergement': {
    tip: 'Attestation sur l\'honneur + pièce d\'identité et justificatif de domicile de l\'hébergeur.',
  },
  'quittance de loyer': {
    tip: '3 dernières quittances de loyer.',
  },

  // ── Emploi ──
  'cdi': {
    tip: 'Copie complète signée par les deux parties.',
  },
  'cdd': {
    tip: 'Copie complète avec date de fin.',
  },
  'contrat de travail': {
    tip: 'Copie complète signée par les deux parties.',
  },
  'attestation employeur': {
    tip: 'Attestation confirmant l\'emploi et la rémunération.',
  },

  // ── Revenus ──
  'bulletin': {
    tip: '3 derniers mois. Téléchargeable depuis votre espace employé en ligne.',
  },

  // ── Fiscal ──
  'avis imposition': {
    tip: '2 dernières années.',
    source: {
      label: 'impots.gouv.fr',
      url: 'https://www.impots.gouv.fr/accueil',
      favicon: 'https://www.google.com/s2/favicons?domain=impots.gouv.fr&sz=32',
    },
  },
  'avis d\'imposition': {
    tip: '2 dernières années.',
    source: {
      label: 'impots.gouv.fr',
      url: 'https://www.impots.gouv.fr/accueil',
      favicon: 'https://www.google.com/s2/favicons?domain=impots.gouv.fr&sz=32',
    },
  },
  'déclaration de revenus': {
    tip: 'Dernière déclaration complète.',
    source: {
      label: 'impots.gouv.fr',
      url: 'https://www.impots.gouv.fr/accueil',
      favicon: 'https://www.google.com/s2/favicons?domain=impots.gouv.fr&sz=32',
    },
  },
  'taxe foncière': {
    tip: 'Dernier avis pour chaque bien possédé.',
    source: {
      label: 'impots.gouv.fr',
      url: 'https://www.impots.gouv.fr/accueil',
      favicon: 'https://www.google.com/s2/favicons?domain=impots.gouv.fr&sz=32',
    },
  },

  // ── Comptes ──
  'relevé': {
    tip: '3 derniers mois, toutes les pages. Téléchargeable depuis l\'espace client de votre banque.',
  },
  'rib': {
    tip: 'Téléchargeable depuis l\'espace client de votre banque.',
  },
  'livret a': {
    tip: 'Dernier relevé, depuis l\'espace client de votre banque.',
  },
  'pel': {
    tip: 'Dernier relevé de votre PEL.',
  },
  'assurance vie': {
    tip: 'Dernier relevé de situation.',
  },
  'pea': {
    tip: 'Dernier relevé de votre PEA.',
  },

  // ── Patrimoine ──
  'titre de propriété': {
    tip: 'Acte notarié pour chaque bien possédé.',
  },
  'tableau d\'amortissement': {
    tip: 'Fourni par votre banque pour chaque prêt en cours.',
  },
  'estimation du bien': {
    tip: 'Estimation par un professionnel ou un notaire.',
  },
  'estimation immobilière': {
    tip: 'Estimation par un professionnel ou un notaire.',
  },

  // ── Projet ──
  'compromis de vente': {
    tip: 'Signé par les deux parties.',
  },
  'plan de financement': {
    tip: 'Plan de financement prévisionnel du projet.',
  },
  'diagnostics immobiliers': {
    tip: 'DPE et diagnostics obligatoires.',
  },
  'devis travaux': {
    tip: 'Devis détaillés signés par les artisans.',
  },
  'permis de construire': {
    tip: 'Copie du permis accordé.',
    source: {
      label: 'Service-Public.fr',
      url: 'https://www.service-public.fr/particuliers/vosdroits/F1986',
      favicon: 'https://www.google.com/s2/favicons?domain=service-public.fr&sz=32',
    },
  },

  // ── UK ──
  'council tax bill': {
    tip: 'Latest council tax bill as proof of UK address.',
    source: {
      label: 'GOV.UK',
      url: 'https://www.gov.uk/council-tax',
      favicon: 'https://www.google.com/s2/favicons?domain=gov.uk&sz=32',
    },
  },
  'p60': {
    tip: 'End-of-year certificate from your employer.',
    source: {
      label: 'GOV.UK',
      url: 'https://www.gov.uk/paye-forms-p45-p60-p11d',
      favicon: 'https://www.google.com/s2/favicons?domain=gov.uk&sz=32',
    },
  },
  'payslip': {
    tip: 'Last 3 months from your employer.',
  },
  'self assessment': {
    tip: 'HMRC Self Assessment tax return.',
    source: {
      label: 'GOV.UK',
      url: 'https://www.gov.uk/self-assessment-tax-returns',
      favicon: 'https://www.google.com/s2/favicons?domain=gov.uk&sz=32',
    },
  },

  // ── US ──
  'w-2': {
    tip: 'Wage and Tax Statement from your employer.',
    source: {
      label: 'IRS',
      url: 'https://www.irs.gov/forms-pubs/about-form-w-2',
      favicon: 'https://www.google.com/s2/favicons?domain=irs.gov&sz=32',
    },
  },
  'tax return': {
    tip: 'Federal tax return (Form 1040), last 2 years.',
    source: {
      label: 'IRS',
      url: 'https://www.irs.gov/individuals/get-transcript',
      favicon: 'https://www.google.com/s2/favicons?domain=irs.gov&sz=32',
    },
  },
  'pay stub': {
    tip: 'Last 3 months from your employer.',
  },
};

export function getDocumentHelp(docName: string): DocumentHelp | null {
  const lower = docName.toLowerCase();
  if (documentHelpMap[lower]) return documentHelpMap[lower];

  let bestMatch: string | null = null;
  let bestLen = 0;
  for (const key of Object.keys(documentHelpMap)) {
    if (lower.includes(key) && key.length > bestLen) {
      bestMatch = key;
      bestLen = key.length;
    }
  }
  return bestMatch ? documentHelpMap[bestMatch] : null;
}
