import { Category, UserProfile } from './types';

const PLACEHOLDER_PDF = 'https://s2.q4cdn.com/175719177/files/doc_presentations/Placeholder-PDF.pdf';

export const categories: Category[] = [
  {
    id: 'f0',
    name: '0 – Mandat Invexa',
    description: 'Documents relatifs au mandat de courtage',
    documents: [
      {
        id: 'm-1',
        name: 'Mandat de courtage',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'mandat_courtage.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '10/03/2025',
      },
      {
        id: 'm-2',
        name: 'Lettre de mission',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'lettre_mission.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '10/03/2025',
      },
    ],
  },
  {
    id: 'f1',
    name: '1 – Identité',
    description: "1 pièce d'identité valide par emprunteur (passeport ou CNI). Si résident fiscal US : Social Security Card requise.",
    documents: [
      {
        id: 'id-1',
        name: 'CNI Paul Durand',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'cni_PD.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '15/03/2025',
      },
      {
        id: 'id-2',
        name: 'Passeport Paul Durand',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'passeport_PD.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '12/03/2025',
      },
      {
        id: 'id-3',
        name: 'CNI Martine Durand',
        person: 'Martine Durand',
        personTag: 'MD',
        status: 'reviewing',
        fileName: 'cni_MD.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '14/03/2025',
      },
      {
        id: 'id-4',
        name: 'Titre de séjour',
        person: 'Martine Durand',
        personTag: 'MD',
        status: 'missing',
      },
    ],
  },
  {
    id: 'f2',
    name: '2 – État civil',
    description: "Selon votre statut : acte de mariage, contrat de mariage (si séparation de biens), convention PACS, jugement de divorce, livret de famille (si enfants).",
    documents: [
      {
        id: 'ec-1',
        name: 'Acte de mariage',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'acte_mariage.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '08/03/2025',
      },
      {
        id: 'ec-2',
        name: 'Livret de famille',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'reviewing',
        fileName: 'livret_famille.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '08/03/2025',
      },
    ],
  },
  {
    id: 'f3',
    name: '3 – Résidence principale',
    description: "Justificatif de domicile de moins de 3 mois. Si locataire : bail. Si propriétaire : tableau d'amortissement + relevé de prêt + acte notarié.",
    documents: [
      {
        id: 'res-1',
        name: 'Justificatif de domicile',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'missing',
        rejectionReason: 'Document manquant — requis',
      },
      {
        id: 'res-2',
        name: 'Bail de location',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'reviewing',
        fileName: 'bail_location.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '05/03/2025',
      },
    ],
  },
  {
    id: 'f4',
    name: '4 – Contrat de travail',
    description: "Contrat de travail en cours + avenant si salaire modifié. Non obligatoire aux USA.",
    documents: [
      {
        id: 'emp-1',
        name: 'CDI Paul Durand',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'cdi_PD.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '01/03/2025',
      },
      {
        id: 'emp-2',
        name: 'CDI Martine Durand',
        person: 'Martine Durand',
        personTag: 'MD',
        status: 'reviewing',
        fileName: 'cdi_MD.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '02/03/2025',
      },
    ],
  },
  {
    id: 'f5',
    name: '5 – Revenus',
    description: "3 derniers bulletins (ou 6 si paie bi-mensuelle) + bulletin de décembre N-1, N-2, N-3. Si bonus : historique sur 3 ans. Si US : W2 ou 1099 sur 3 ans. Si dirigeant : Kbis, statuts, P&L, attestation expert-comptable, dividendes.",
    documents: [
      // Paul — 3 derniers mois
      { id: 'rev-1', name: 'Mois 1/3', person: 'Paul Durand', personTag: 'PD', status: 'validated', fileName: 'bs_mars_PD.pdf', fileUrl: PLACEHOLDER_PDF, date: '28/03/2025', group: 'Bulletins de salaire — Paul Durand' },
      { id: 'rev-2', name: 'Mois 2/3', person: 'Paul Durand', personTag: 'PD', status: 'reviewing', fileName: 'bs_fev_PD.pdf', fileUrl: PLACEHOLDER_PDF, date: '28/02/2025', group: 'Bulletins de salaire — Paul Durand' },
      { id: 'rev-3', name: 'Mois 3/3', person: 'Paul Durand', personTag: 'PD', status: 'reviewing', fileName: 'bs_jan_PD.pdf', fileUrl: PLACEHOLDER_PDF, date: '31/01/2025', group: 'Bulletins de salaire — Paul Durand' },
      // Paul — bulletins décembre
      { id: 'rev-4', name: 'Décembre 2025', person: 'Paul Durand', personTag: 'PD', status: 'validated', fileName: 'bs_dec2025_PD.pdf', fileUrl: PLACEHOLDER_PDF, date: '31/12/2025', group: 'Bulletins de décembre — Paul Durand' },
      { id: 'rev-5', name: 'Décembre 2024', person: 'Paul Durand', personTag: 'PD', status: 'validated', fileName: 'bs_dec2024_PD.pdf', fileUrl: PLACEHOLDER_PDF, date: '31/12/2024', group: 'Bulletins de décembre — Paul Durand' },
      { id: 'rev-6', name: 'Décembre 2023', person: 'Paul Durand', personTag: 'PD', status: 'missing', group: 'Bulletins de décembre — Paul Durand' },
      // Martine — 3 derniers mois
      { id: 'rev-7', name: 'Mois 1/3', person: 'Martine Durand', personTag: 'MD', status: 'rejected', fileName: 'bs_mars_MD.pdf', fileUrl: PLACEHOLDER_PDF, rejectionReason: 'Document illisible', date: '28/03/2025', group: 'Bulletins de salaire — Martine Durand' },
      { id: 'rev-8', name: 'Mois 2/3', person: 'Martine Durand', personTag: 'MD', status: 'missing', group: 'Bulletins de salaire — Martine Durand' },
      { id: 'rev-9', name: 'Mois 3/3', person: 'Martine Durand', personTag: 'MD', status: 'missing', group: 'Bulletins de salaire — Martine Durand' },
      // Martine — bulletins décembre
      { id: 'rev-10', name: 'Décembre 2025', person: 'Martine Durand', personTag: 'MD', status: 'missing', group: 'Bulletins de décembre — Martine Durand' },
      { id: 'rev-11', name: 'Décembre 2024', person: 'Martine Durand', personTag: 'MD', status: 'missing', group: 'Bulletins de décembre — Martine Durand' },
      { id: 'rev-12', name: 'Décembre 2023', person: 'Martine Durand', personTag: 'MD', status: 'missing', group: 'Bulletins de décembre — Martine Durand' },
    ],
  },
  {
    id: 'f6',
    name: '6 – Dossier fiscal',
    description: "Avis d'imposition N-1, N-2 et N-3. Si séparation de biens ou non mariés : 1 avis par personne. Si dirigeant : déclaration fiscale société sur 3 ans.",
    documents: [
      {
        id: 'imp-1',
        name: 'Avis imposition 2023',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'avis_imposition_PD.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '20/03/2025',
      },
      {
        id: 'imp-2',
        name: 'Avis imposition 2023',
        person: 'Martine Durand',
        personTag: 'MD',
        status: 'reviewing',
        fileName: 'avis_imposition_MD.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '22/03/2025',
      },
    ],
  },
  {
    id: 'f7',
    name: '7 – Comptes courants',
    description: "3 derniers mois calendaires complets par compte courant détenu (individuel + joint). Inclure également les relevés de carte bancaire (1 par carte par mois).",
    documents: [
      {
        id: 'cpt-1',
        name: 'Relevé Mars 2025',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'releve_mars.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '31/03/2025',
      },
      {
        id: 'cpt-2',
        name: 'Relevé Févr 2025',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'reviewing',
        fileName: 'releve_fev.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '28/02/2025',
      },
      {
        id: 'cpt-3',
        name: 'Relevé Mai 2024',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'missing',
      },
    ],
  },
  {
    id: 'f8',
    name: '8 – Comptes épargne',
    description: "3 derniers mois par compte épargne détenu : Livret A, PEL, assurance-vie, PEA, crypto, retraite. Comptes joints et individuels.",
    documents: [
      {
        id: 'ep-1',
        name: 'Relevé Livret A',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'reviewing',
        fileName: 'livret_a.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '15/03/2025',
      },
    ],
  },
  {
    id: 'f9',
    name: '9 – Patrimoine immobilier',
    description: "Par bien détenu : taxe foncière N-1, contrat de bail (si loué), revenus fonciers (décl. 2044), contrat de prêt + tableau d'amortissement + relevé (si financé). Si via société : Kbis, statuts, P&L et déclaration fiscale IS.",
    documents: [
      {
        id: 'pat-1',
        name: "Tableau d'amortissement",
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'missing',
        rejectionReason: "Tableau d'amortissement du prêt en cours",
      },
      {
        id: 'pat-2',
        name: 'Taxe foncière 2023',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'taxe_fonciere.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '18/03/2025',
      },
      {
        id: 'pat-3',
        name: 'Titre de propriété',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'titre_propriete.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '10/03/2025',
      },
    ],
  },
  {
    id: 'f10',
    name: '10 – Projet à financer',
    description: "Par projet : compromis de vente, coordonnées notaire, DPE. Si investissement locatif : attestation de valeur locative. Si travaux : devis + DPE projeté.",
    documents: [
      {
        id: 'prj-1',
        name: 'Plan de financement',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'missing',
        rejectionReason: 'Plan de financement prévisionnel requis',
      },
      {
        id: 'prj-2',
        name: 'Diagnostics immobiliers',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'missing',
        rejectionReason: 'DPE et diagnostics obligatoires',
      },
      {
        id: 'prj-3',
        name: 'Estimation du bien',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'reviewing',
        fileName: 'estimation_bien.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '25/03/2025',
      },
      {
        id: 'prj-4',
        name: 'Compromis de vente',
        person: 'Paul Durand',
        personTag: 'PD',
        status: 'validated',
        fileName: 'compromis_vente.pdf',
        fileUrl: PLACEHOLDER_PDF,
        date: '01/04/2025',
      },
    ],
  },
];

/* ─── User profiles ─── */

export const completedProfile: UserProfile = {
  // Identity
  civility: 'monsieur',
  firstName: 'Paul',
  lastName: 'Durand',
  birthDate: '15/06/1985',
  nationality: 'Américaine',
  email: 'paul@invexa-test.com',
  phone: '+1 555 123 4567',
  countryOfResidence: 'États-Unis',

  // Family — married with co-borrower
  maritalStatus: 'marie',
  matrimonialRegime: 'separation_biens',
  coEmprunteurRelation: 'conjoint',
  coEmprunteurFirstName: 'Martine',
  coEmprunteurLastName: 'Durand',
  hasPensionAlimentaire: false,

  // Children
  children: [
    { firstName: 'Lucas', birthDate: '12/03/2018' },
    { firstName: 'Emma', birthDate: '25/09/2020' },
    { firstName: 'Hugo', birthDate: '04/01/2023' },
  ],

  // Residence — owner in the US with active loan
  address: '45 West 25th Street',
  postalCode: '10010',
  city: 'New York',
  country: 'États-Unis',
  housingStatus: 'proprietaire',
  hasLoanRP: true,
  loanDetailsRP: {
    bankName: 'Chase',
    monthlyPayment: 2100,
  },

  // Professional — CDI + dirigeant
  professionalStatus: 'salarie_cdi',
  profession: 'Directeur financier',
  company: 'TechCorp Inc.',
  workCountry: 'États-Unis',
  payFrequency: 'bi_weekly',
  hasBonus: true,
  isUS: true,
  isDirigeant: true,
  dirigeantCompanyName: 'Durand Consulting SAS',

  // Real estate — 2 properties
  realEstateProperties: [
    {
      id: 'prop-1',
      address: '18 rue de Rivoli, 75004 Paris',
      type: 'Appartement',
      usage: 'loue',
      hasLoan: true,
      loanDetails: {
        bankName: 'BNP Paribas',
        monthlyPayment: 850,
      },
      viaSociete: true,
      societeName: 'SCI Durand Patrimoine',
    },
    {
      id: 'prop-2',
      address: '7 allée des Chênes, 33000 Bordeaux',
      type: 'Maison',
      usage: 'loue',
      hasLoan: true,
      loanDetails: {
        bankName: 'Crédit Agricole',
        monthlyPayment: 620,
      },
      viaSociete: false,
    },
    {
      id: 'prop-3',
      address: '3 place Bellecour, 69002 Lyon',
      type: 'Appartement',
      usage: 'occupe',
      hasLoan: false,
      viaSociete: true,
      societeName: 'SCI Durand & Fils',
    },
  ],

  // Projects — 2 projects
  projects: [
    {
      id: 'proj-1',
      type: 'investissement_locatif',
      label: 'Appartement Lyon 6e',
      amount: 320000,
      location: 'Lyon 6e',
      notaryName: 'Me. Lefèvre',
      isInvestissementLocatif: true,
      hasDevisTravaux: false,
    },
    {
      id: 'proj-2',
      type: 'travaux',
      label: 'Rénovation maison Bordeaux',
      amount: 85000,
      location: 'Bordeaux',
      notaryName: 'Me. Garcia',
      isInvestissementLocatif: false,
      hasDevisTravaux: true,
    },
  ],

  profileValidated: true,
  coEmprunteurAccess: true,
};

export const pendingProfile: UserProfile = {
  ...completedProfile,
  email: 'validation@invexa-test.com',
  profileValidated: false,
  coEmprunteurAccess: false,
};

export function getProfileByEmail(email: string): UserProfile | null {
  if (email === 'paul@invexa-test.com') return JSON.parse(JSON.stringify(completedProfile));
  if (email === 'validation@invexa-test.com') return JSON.parse(JSON.stringify(pendingProfile));
  return null;
}
