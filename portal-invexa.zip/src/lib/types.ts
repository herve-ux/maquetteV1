/* ─── Documents ─── */

export type DocumentStatus =
  | 'missing'
  | 'uploaded'
  | 'reviewing'
  | 'validated'
  | 'rejected';

export interface DocumentItem {
  id: string;
  name: string;
  person: string;
  personTag: 'PD' | 'MD' | 'both';
  status: DocumentStatus;
  fileName?: string;
  fileUrl?: string;
  rejectionReason?: string;
  date?: string;
  group?: string;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  documents: DocumentItem[];
}

/* ─── Profile ─── */

export type Civility = 'monsieur' | 'madame';
export type MaritalStatus = 'celibataire' | 'marie' | 'pacse' | 'divorce' | 'concubin';
export type MatrimonialRegime = 'communaute_legale' | 'separation_biens' | 'communaute_universelle' | 'participation_acquets';
export type CoEmprunteurRelation = 'conjoint' | 'partenaire_pacs' | 'concubin' | 'frere_soeur' | 'parent_enfant' | 'associe' | 'ami' | 'autre';
export type HousingStatus = 'locataire' | 'proprietaire';
export type ProfessionalStatus = 'salarie_cdi' | 'salarie_cdd' | 'fonctionnaire' | 'independant' | 'dirigeant';
export type PropertyUsage = 'loue' | 'occupe';
export type ProjectType = 'acquisition_residence' | 'investissement_locatif' | 'travaux';

export interface Child {
  firstName: string;
  birthDate: string;
}

export interface LoanDetails {
  bankName: string;
  monthlyPayment: number;
}

export type PayFrequency = 'mensuel' | 'bi_weekly';

export interface RealEstateProperty {
  id: string;
  address: string;
  type: string;
  usage: PropertyUsage;
  hasLoan: boolean;
  loanDetails?: LoanDetails;
  viaSociete: boolean;
  societeName?: string;
}

export interface ProjectToFinance {
  id: string;
  type: ProjectType | '';
  label: string;
  amount: number;
  location: string;
  notaryName: string;
  isInvestissementLocatif: boolean;
  hasDevisTravaux: boolean;
}

export interface UserProfile {
  // Identity
  civility: Civility | '';
  firstName: string;
  lastName: string;
  birthDate: string;
  nationality: string;
  email: string;
  phone: string;
  countryOfResidence: string;

  // Family
  maritalStatus: MaritalStatus | '';
  matrimonialRegime?: MatrimonialRegime;
  coEmprunteurRelation?: CoEmprunteurRelation;
  coEmprunteurFirstName?: string;
  coEmprunteurLastName?: string;
  hasPensionAlimentaire?: boolean;
  pensionAmount?: number;

  // Children
  children: Child[];

  // Residence
  address: string;
  postalCode: string;
  city: string;
  country: string;
  housingStatus: HousingStatus | '';
  hasLoanRP: boolean;
  loanDetailsRP?: LoanDetails;

  // Professional
  professionalStatus: ProfessionalStatus | '';
  profession: string;
  company: string;
  workCountry: string;
  payFrequency: PayFrequency | '';
  hasBonus: boolean;
  isUS: boolean;
  isDirigeant: boolean;
  dirigeantCompanyName?: string;

  // Real estate patrimony
  realEstateProperties: RealEstateProperty[];

  // Projects to finance
  projects: ProjectToFinance[];

  // Validation
  profileValidated: boolean;

  // Consent (separate)
  coEmprunteurAccess: boolean;
}
