'use client';

import { useState, FormEvent } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [phoneCode, setPhoneCode] = useState('+33');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const countryCodes = [
    { code: '+33', flag: '🇫🇷', label: 'France' },
    { code: '+44', flag: '🇬🇧', label: 'Royaume-Uni' },
    { code: '+1', flag: '🇺🇸', label: 'États-Unis' },
    { code: '+49', flag: '🇩🇪', label: 'Allemagne' },
    { code: '+34', flag: '🇪🇸', label: 'Espagne' },
    { code: '+39', flag: '🇮🇹', label: 'Italie' },
    { code: '+41', flag: '🇨🇭', label: 'Suisse' },
    { code: '+32', flag: '🇧🇪', label: 'Belgique' },
    { code: '+352', flag: '🇱🇺', label: 'Luxembourg' },
    { code: '+351', flag: '🇵🇹', label: 'Portugal' },
    { code: '+31', flag: '🇳🇱', label: 'Pays-Bas' },
    { code: '+46', flag: '🇸🇪', label: 'Suède' },
    { code: '+65', flag: '🇸🇬', label: 'Singapour' },
    { code: '+852', flag: '🇭🇰', label: 'Hong Kong' },
    { code: '+971', flag: '🇦🇪', label: 'Émirats arabes unis' },
    { code: '+974', flag: '🇶🇦', label: 'Qatar' },
    { code: '+212', flag: '🇲🇦', label: 'Maroc' },
    { code: '+61', flag: '🇦🇺', label: 'Australie' },
    { code: '+81', flag: '🇯🇵', label: 'Japon' },
  ];

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    localStorage.setItem('invexa-email', email);
    await new Promise((r) => setTimeout(r, 600));
    router.push('/dashboard');
  };

  const fillTestAccount = (testEmail: string) => {
    setEmail(testEmail);
    setPassword('test');
    setMode('login');
  };

  const bankLogos = ['/banks/bnp.jpg', '/banks/sg.png', '/banks/ca.png', '/banks/lcl.png', '/banks/cic.png', '/banks/bp.png', '/banks/ce.png'];

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Image panel — team photo */}
      <div className="relative h-48 sm:h-56 lg:h-auto lg:w-1/2 overflow-hidden bg-neutral-100">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/Invexa_Portraits_DRF_Photography-5 (1).jpg"
          alt="L'équipe Invexa"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
        <div className="hidden lg:flex absolute bottom-8 left-8 flex-col gap-0.5">
          <p className="text-white/90 text-sm font-medium">Invexa</p>
          <p className="text-white/60 text-xs">Votre courtier pour les Français de l&apos;étranger</p>
        </div>
      </div>

      {/* Form panel */}
      <div className="flex-1 flex flex-col px-6 py-8 lg:px-12 lg:py-10">

        {/* Top — Logo */}
        <div className="flex justify-center lg:justify-start">
          <img
            src="/invexa-logo-black.webp"
            alt="Invexa"
            className="h-7"
          />
        </div>

        {/* Center — Title + Form */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="w-full max-w-[360px] animate-fade-in">
            {/* Title */}
            <div className="mb-8 text-center">
              <h1 className="text-xl font-semibold text-black leading-snug">
                Finalisez votre dossier
              </h1>
              <p className="text-neutral-400 text-sm mt-1.5">
                {mode === 'login'
                  ? 'Retrouvez votre espace sécurisé'
                  : 'Créez votre compte en quelques secondes'}
              </p>
            </div>

            {/* Toggle */}
            <div className="flex bg-neutral-100 rounded-xl p-1 mb-7">
              <button
                type="button"
                onClick={() => setMode('login')}
                className={`flex-1 text-xs font-semibold py-2 rounded-lg transition-all duration-200
                  ${mode === 'login' ? 'bg-white text-black shadow-sm' : 'text-neutral-400 hover:text-neutral-600'}`}
              >
                Se connecter
              </button>
              <button
                type="button"
                onClick={() => setMode('signup')}
                className={`flex-1 text-xs font-semibold py-2 rounded-lg transition-all duration-200
                  ${mode === 'signup' ? 'bg-white text-black shadow-sm' : 'text-neutral-400 hover:text-neutral-600'}`}
              >
                Créer un compte
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label htmlFor="email" className="block text-xs font-medium text-neutral-500 mb-1.5 uppercase tracking-wider">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="paul@invexa-test.com"
                  className="w-full h-10 px-4 rounded-xl border border-neutral-200 bg-white text-sm
                             placeholder:text-neutral-300
                             focus:outline-none focus:border-black focus:ring-1 focus:ring-black
                             transition-all duration-200"
                />
              </div>

              {mode === 'signup' && (
                <div className="animate-fadeIn">
                  <label htmlFor="phone" className="block text-xs font-medium text-neutral-500 mb-1.5 uppercase tracking-wider">
                    Téléphone
                  </label>
                  <div className="flex gap-2">
                    <div className="relative flex-shrink-0">
                      <select
                        value={phoneCode}
                        onChange={(e) => setPhoneCode(e.target.value)}
                        className="h-10 pl-3 pr-8 rounded-xl border border-neutral-200 bg-white text-sm
                                   appearance-none cursor-pointer
                                   focus:outline-none focus:border-black focus:ring-1 focus:ring-black
                                   transition-all duration-200"
                      >
                        {countryCodes.map((c) => (
                          <option key={c.code} value={c.code}>
                            {c.flag} {c.code}
                          </option>
                        ))}
                      </select>
                      <svg className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-neutral-400" width="10" height="10" viewBox="0 0 10 10" fill="none">
                        <path d="M2.5 4L5 6.5L7.5 4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <input
                      id="phone"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="6 12 34 56 78"
                      className="flex-1 h-10 px-4 rounded-xl border border-neutral-200 bg-white text-sm
                                 placeholder:text-neutral-300
                                 focus:outline-none focus:border-black focus:ring-1 focus:ring-black
                                 transition-all duration-200"
                    />
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1.5">
                    Utilisé pour la vérification en deux étapes (2FA)
                  </p>
                </div>
              )}

              <div>
                <label htmlFor="password" className="block text-xs font-medium text-neutral-500 mb-1.5 uppercase tracking-wider">
                  Mot de passe
                </label>
                <input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full h-10 px-4 rounded-xl border border-neutral-200 bg-white text-sm
                             placeholder:text-neutral-300
                             focus:outline-none focus:border-black focus:ring-1 focus:ring-black
                             transition-all duration-200"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full h-10 bg-black text-white text-sm font-semibold rounded-xl
                           hover:bg-neutral-800 active:scale-95
                           disabled:opacity-60 disabled:cursor-not-allowed
                           transition-all duration-200 mt-2"
              >
                {loading ? (
                  <span className="inline-flex items-center gap-2">
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    {mode === 'login' ? 'Connexion...' : 'Création...'}
                  </span>
                ) : mode === 'login' ? (
                  'Se connecter'
                ) : (
                  'Créer mon compte'
                )}
              </button>
            </form>

            {mode === 'login' && (
              <p className="text-center mt-5 text-xs text-neutral-400">
                Mot de passe oublié ?{' '}
                <button className="text-black underline underline-offset-2 hover:no-underline">
                  Réinitialiser
                </button>
              </p>
            )}

            {/* Test accounts */}
            <div className="mt-6 rounded-xl border border-dashed border-neutral-200 bg-neutral-50/50 p-4">
              <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider mb-3">Comptes de démonstration</p>
              <div className="space-y-1.5">
                <button
                  type="button"
                  onClick={() => fillTestAccount('paul@invexa-test.com')}
                  className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-white border border-transparent hover:border-neutral-100 transition-all text-xs cursor-pointer bg-transparent"
                >
                  <span className="font-semibold text-black">paul@invexa-test.com</span>
                  <span className="text-neutral-400 ml-1.5">— Profil complet, dossier en cours</span>
                </button>
                <button
                  type="button"
                  onClick={() => fillTestAccount('validation@invexa-test.com')}
                  className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-white border border-transparent hover:border-neutral-100 transition-all text-xs cursor-pointer bg-transparent"
                >
                  <span className="font-semibold text-black">validation@invexa-test.com</span>
                  <span className="text-neutral-400 ml-1.5">— Profil pré-rempli, à valider</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom — Trust signals */}
        <div className="flex items-center justify-between gap-4 pt-4">
          <div className="flex items-center gap-2.5">
            <div className="flex -space-x-1.5">
              {bankLogos.map((src, i) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  key={i}
                  src={src}
                  alt=""
                  width={24}
                  height={24}
                  className="w-6 h-6 rounded-full border-[1.5px] border-white object-cover bg-white"
                />
              ))}
            </div>
            <span className="text-[11px] text-neutral-400 hidden sm:inline">Nos partenaires</span>
          </div>
          <div className="flex items-center gap-2">
            <svg width="18" height="13" viewBox="0 0 20 14" fill="none" className="flex-shrink-0">
              <rect width="20" height="14" rx="2" fill="#003399" />
              {Array.from({ length: 12 }).map((_, i) => {
                const angle = (i * 30 - 90) * (Math.PI / 180);
                const cx = 10 + 4.5 * Math.cos(angle);
                const cy = 7 + 4.5 * Math.sin(angle);
                return <circle key={i} cx={cx} cy={cy} r="0.7" fill="#FFCC00" />;
              })}
            </svg>
            <span className="text-[11px] text-neutral-400">Hébergé en France · RGPD</span>
          </div>
        </div>
      </div>
    </div>
  );
}
