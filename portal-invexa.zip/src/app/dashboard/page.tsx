'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { categories as initialCategories, getProfileByEmail } from '@/lib/data';
import {
  Category, DocumentItem, DocumentStatus, UserProfile,
  RealEstateProperty, ProjectToFinance,
  MaritalStatus, HousingStatus, ProfessionalStatus, ProjectType, Civility,
  MatrimonialRegime, CoEmprunteurRelation,
} from '@/lib/types';
import DocumentSlot from '@/components/DocumentSlot';

/* ─── Helpers ─── */

function getCategoryStats(cat: Category) {
  const total = cat.documents.length;
  const done = cat.documents.filter((d) => d.status === 'validated' || d.status === 'uploaded' || d.status === 'reviewing').length;
  const actions = cat.documents.filter((d) => d.status === 'missing' || d.status === 'rejected').length;
  return { total, done, actions };
}

function isComplete(cat: Category) {
  return cat.documents.every((d) => d.status === 'validated' || d.status === 'uploaded' || d.status === 'reviewing');
}

type Tab = 'documents' | 'profil' | 'accueil';

const CheckIcon = ({ size = 10 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 12 12" fill="none">
    <path d="M2.5 6L5 8.5L9.5 3.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const LockMiniIcon = () => (
  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-300">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0110 0v4" />
  </svg>
);

/* ─── Category icons ─── */
const categoryIcons: Record<string, React.ReactNode> = {
  f0: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9" /><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z" /></svg>,
  f1: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="20" height="14" rx="2" /><line x1="2" y1="10" x2="22" y2="10" /><circle cx="8" cy="15" r="1.5" /><path d="M14 13h4M14 16h2" /></svg>,
  f2: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z" /></svg>,
  f3: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" /><polyline points="9 22 9 12 15 12 15 22" /></svg>,
  f4: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2" /><path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2" /><line x1="12" y1="12" x2="12" y2="12.01" /></svg>,
  f5: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="6" width="22" height="14" rx="2" /><path d="M1 10h22" /><circle cx="18" cy="14" r="1" /></svg>,
  f6: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 2v20l3-2 3 2 3-2 3 2 3-2 3 2V2l-3 2-3-2-3 2-3-2-3 2-3-2z" /><path d="M8 10h8M8 14h4" /></svg>,
  f7: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 21h18M3 10h18M5 6l7-3 7 3" /><path d="M6 10v7M10 10v7M14 10v7M18 10v7" /></svg>,
  f8: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><path d="M9 12l2 2 4-4" /></svg>,
  f9: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="2" width="16" height="20" rx="1" /><path d="M9 22V12h6v10" /><path d="M8 6h.01M12 6h.01M16 6h.01M8 9h.01M12 9h.01M16 9h.01" /></svg>,
  f10: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4" /></svg>,
};

/* ═══ MAIN ═══ */

export default function DashboardPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>(initialCategories);
  const [activeCategoryIndex, setActiveCategoryIndex] = useState(() => {
    const idx = initialCategories.findIndex((c) => !isComplete(c));
    return idx >= 0 ? idx : 0;
  });
  const [showDropdown, setShowDropdown] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout>>(null);
  const [previewDoc, setPreviewDoc] = useState<DocumentItem | null>(null);

  // Profile state — loaded from localStorage email
  const [profile, setProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    const email = localStorage.getItem('invexa-email');
    const p = email ? getProfileByEmail(email) : null;
    if (!p) { router.push('/login'); return; }
    setProfile(p);
  }, [router]);

  const [activeTab, setActiveTab] = useState<Tab>('documents');

  // Sync tab when profile loads
  useEffect(() => {
    if (profile && !profile.profileValidated) setActiveTab('profil');
  }, [profile]);

  // Early return while loading / redirecting
  if (!profile) return null;

  const activeCategory = categories[activeCategoryIndex];
  const stats = getCategoryStats(activeCategory);
  const allDocs = categories.flatMap((c) => c.documents);
  const globalStats = {
    total: allDocs.length,
    done: allDocs.filter((d) => d.status === 'validated' || d.status === 'uploaded' || d.status === 'reviewing').length,
    actions: allDocs.filter((d) => d.status === 'missing' || d.status === 'rejected').length,
  };

  const pct = Math.round((globalStats.done / globalStats.total) * 100);

  const showToast = (msg: string) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast(msg);
    toastTimer.current = setTimeout(() => setToast(null), 3000);
  };

  const handleUpload = (docId: string, fileName: string, fileUrl: string) => {
    setCategories((prev) => {
      const next = prev.map((cat) => ({
        ...cat,
        documents: cat.documents.map((doc) =>
          doc.id === docId ? { ...doc, status: 'uploaded' as DocumentStatus, fileName, fileUrl, rejectionReason: undefined } : doc
        ),
      }));
      const remaining = next.flatMap((c) => c.documents).filter((d) => d.status === 'missing' || d.status === 'rejected').length;
      const docName = prev.flatMap((c) => c.documents).find((d) => d.id === docId)?.name ?? fileName;
      setTimeout(() => showToast(remaining > 0 ? `${docName} déposé · ${remaining} restant${remaining > 1 ? 's' : ''}` : `${docName} déposé · Dossier complet`), 0);
      return next;
    });
  };

  const handleReset = (docId: string) => {
    setCategories((prev) => prev.map((cat) => ({
      ...cat,
      documents: cat.documents.map((doc) =>
        doc.id === docId ? { ...doc, status: 'missing' as DocumentStatus, fileName: undefined, fileUrl: undefined } : doc
      ),
    })));
  };

  const goNext = () => {
    const nextIncomplete = categories.findIndex((c, i) => i > activeCategoryIndex && !isComplete(c));
    if (nextIncomplete >= 0) setActiveCategoryIndex(nextIncomplete);
    else if (activeCategoryIndex < categories.length - 1) setActiveCategoryIndex(activeCategoryIndex + 1);
  };
  const goPrev = () => { if (activeCategoryIndex > 0) setActiveCategoryIndex(activeCategoryIndex - 1); };

  const displayName = profile.firstName ? `${profile.firstName} ${profile.lastName}` : 'Client';
  const initials = profile.firstName ? `${profile.firstName[0]}${profile.lastName[0]}` : '?';

  const tabs: { id: Tab; label: string; disabled: boolean }[] = [
    { id: 'documents', label: 'Documents', disabled: !profile.profileValidated },
    { id: 'profil', label: 'Profil', disabled: false },
    { id: 'accueil', label: 'Statut', disabled: !profile.profileValidated },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* ═══ HEADER ═══ */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <img src="/invexa-logo-black.webp" alt="Invexa" className="h-5 flex-shrink-0" />
            <nav className="flex items-center gap-1">
              {tabs.map((tab) => (
                <button key={tab.id}
                  onClick={() => !tab.disabled && setActiveTab(tab.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                    tab.disabled ? 'text-neutral-200 cursor-not-allowed' :
                    activeTab === tab.id ? 'bg-accent-50 text-black' : 'text-neutral-400 hover:text-black'
                  }`}>
                  {tab.disabled && <LockMiniIcon />}
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-neutral-400 hidden sm:block">{displayName}</span>
            <div className="relative">
              <button onClick={() => setShowDropdown(!showDropdown)} className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-xs font-bold cursor-pointer">{initials}</button>
              {showDropdown && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowDropdown(false)} />
                  <div className="absolute top-[calc(100%+8px)] right-0 w-[240px] rounded-2xl z-50 bg-white border border-neutral-100 shadow-lg overflow-hidden">
                    <div className="p-4 pb-3 border-b border-neutral-100">
                      <p className="text-sm font-semibold">{displayName}</p>
                      <p className="text-xs text-neutral-400 mt-0.5">{profile.email}</p>
                    </div>
                    <div className="p-1.5">
                      <button onClick={() => { setShowDropdown(false); setActiveTab('profil'); }} className="w-full flex items-center gap-2.5 p-2.5 rounded-xl text-left text-sm hover:bg-neutral-50 transition-colors cursor-pointer bg-transparent border-none">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>
                        Mon profil
                      </button>
                    </div>
                    <div className="h-px mx-3 bg-neutral-100" />
                    <div className="p-1.5">
                      <button onClick={() => { setShowDropdown(false); localStorage.removeItem('invexa-email'); router.push('/login'); }} className="w-full flex items-center gap-2.5 p-2.5 rounded-xl text-left text-sm text-red-500 hover:bg-red-50 transition-colors cursor-pointer bg-transparent border-none">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" /></svg>
                        Se déconnecter
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* ═══ STATUT TAB ═══ */}
      {activeTab === 'accueil' && (() => {
        const steps = [
          { label: 'Constitution du dossier', desc: 'Collecte de vos documents', done: pct >= 20 },
          { label: 'Vérification', desc: 'Analyse par votre conseiller', done: pct >= 50 },
          { label: 'Envoi aux banques', desc: 'Transmission aux partenaires', done: pct >= 80 },
          { label: 'Offre de prêt', desc: 'Réception et comparaison', done: false },
          { label: 'Signature', desc: 'Finalisation chez le notaire', done: false },
        ];
        const currentStep = steps.findIndex((s) => !s.done);
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
            <div className="flex items-baseline justify-between mb-6">
              <div>
                <h1 className="text-xl font-bold mb-1">Votre dossier</h1>
                <p className="text-sm text-neutral-400">Étape {currentStep + 1} sur {steps.length}</p>
              </div>
              <span className="text-2xl font-bold">{pct}%</span>
            </div>

            <div className="h-1.5 bg-neutral-100 rounded-full overflow-hidden mb-8">
              <div className="h-full bg-accent rounded-full transition-all duration-700" style={{ width: `${pct}%` }} />
            </div>

            <div className="space-y-2 sm:space-y-0 sm:grid sm:grid-cols-5 sm:gap-3 mb-8">
              {steps.map((step, i) => {
                const isCurrent = i === currentStep;
                return (
                  <div key={i} className={`flex sm:flex-col items-center sm:text-center rounded-2xl border p-3 sm:p-4 gap-3 sm:gap-0 transition-all ${
                    step.done ? 'border-neutral-100 bg-neutral-50/50' : isCurrent ? 'border-accent-dark bg-accent-50' : 'border-neutral-100 bg-white'
                  }`}>
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold sm:mb-2 ${
                      step.done ? 'bg-black text-white' : isCurrent ? 'bg-accent-dark text-black' : 'bg-neutral-100 text-neutral-400'
                    }`}>
                      {step.done ? <CheckIcon size={9} /> : i + 1}
                    </div>
                    <div className="sm:contents">
                      <p className={`text-[11px] font-semibold leading-tight sm:mb-0.5 ${step.done ? 'text-neutral-400' : 'text-black'}`}>{step.label}</p>
                      <p className="text-[10px] text-neutral-400 leading-tight">{step.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="rounded-2xl border border-neutral-100 p-5 mb-4">
              <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider mb-4">Mon projet</p>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-x-6 gap-y-3 text-xs">
                {profile.projects[0] && (
                  <>
                    <div><span className="text-neutral-400 block mb-0.5">Type</span><span className="text-black font-medium">{profile.projects[0].type === 'investissement_locatif' ? 'Investissement locatif' : profile.projects[0].type === 'acquisition_residence' ? 'Acquisition résidence' : 'Travaux'}</span></div>
                    <div><span className="text-neutral-400 block mb-0.5">Montant</span><span className="text-black font-semibold">{profile.projects[0].amount.toLocaleString('fr-FR')} €</span></div>
                    <div><span className="text-neutral-400 block mb-0.5">Notaire</span><span className="text-black font-medium">{profile.projects[0].notaryName}</span></div>
                    <div><span className="text-neutral-400 block mb-0.5">Localisation</span><span className="text-black font-medium">{profile.projects[0].location}</span></div>
                  </>
                )}
                <div><span className="text-neutral-400 block mb-0.5">Emprunteur</span><span className="text-black font-medium">{profile.firstName} {profile.lastName}</span></div>
                {profile.coEmprunteurFirstName && <div><span className="text-neutral-400 block mb-0.5">Co-emprunteur</span><span className="text-black font-medium">{profile.coEmprunteurFirstName} {profile.coEmprunteurLastName}</span></div>}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="flex -space-x-1.5">
                  {['/banks/bnp.jpg', '/banks/sg.png', '/banks/ca.png', '/banks/lcl.png', '/banks/cic.png', '/banks/bp.png', '/banks/ce.png'].map((src, i) => (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img key={i} src={src} alt="" width={24} height={24} className="w-6 h-6 rounded-full border-[1.5px] border-white object-cover bg-white" />
                  ))}
                </div>
                <span className="text-[11px] text-neutral-400 hidden sm:inline">Nos partenaires</span>
              </div>
              <GDPRBadge />
            </div>
          </div>
        );
      })()}

      {/* ═══ DOCUMENTS TAB ═══ */}
      {activeTab === 'documents' && (
        <>
          <div className="sm:hidden border-b border-neutral-100 px-4 py-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-neutral-500">Étape {activeCategoryIndex + 1} / {categories.length}</span>
              <span className="text-xs text-neutral-400">{globalStats.done}/{globalStats.total}</span>
            </div>
            <div className="h-1 bg-neutral-100 rounded-full overflow-hidden">
              <div className="h-full bg-accent rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
            </div>
            <div className="flex gap-1 mt-3 overflow-x-auto pb-1 no-scrollbar">
              {categories.map((cat, i) => (
                <button key={cat.id} onClick={() => setActiveCategoryIndex(i)}
                  className={`flex-shrink-0 h-8 px-3 rounded-full text-xs font-medium transition-all ${i === activeCategoryIndex ? 'bg-black text-white' : isComplete(cat) ? 'bg-neutral-100 text-neutral-500' : 'bg-accent-50 text-black'}`}>
                  {cat.name.replace(/^\d+ – /, '')}
                </button>
              ))}
            </div>
          </div>

          <div className="max-w-7xl mx-auto flex">
            <aside className="hidden sm:block w-72 flex-shrink-0 border-r border-neutral-100 min-h-[calc(100vh-3.5rem)] sticky top-14 self-start">
              <div className="p-6">
                <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider mb-3">Mon dossier</p>
                <div className="flex items-baseline gap-2 mb-2">
                  <span className="text-2xl font-bold">{globalStats.done}</span>
                  <span className="text-sm text-neutral-400">/ {globalStats.total} documents</span>
                </div>
                <div className="h-1.5 bg-neutral-100 rounded-full overflow-hidden">
                  <div className="h-full bg-accent rounded-full transition-all duration-700" style={{ width: `${pct}%` }} />
                </div>
                {globalStats.actions > 0 && <p className="text-xs text-neutral-400 mt-2">{globalStats.actions} action{globalStats.actions > 1 ? 's' : ''} restante{globalStats.actions > 1 ? 's' : ''}</p>}

                <nav className="mt-5 space-y-px">
                  {categories.map((cat, i) => {
                    const complete = isComplete(cat);
                    const active = i === activeCategoryIndex;
                    const cs = getCategoryStats(cat);
                    return (
                      <button key={cat.id} onClick={() => setActiveCategoryIndex(i)}
                        className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[12px] transition-all flex items-center gap-2.5 ${active ? 'bg-accent-50 font-semibold text-black' : complete ? 'text-neutral-400 hover:bg-neutral-50' : 'text-neutral-600 hover:bg-neutral-50'}`}
                        style={{ border: 'none', background: active ? undefined : 'transparent' }}>
                        <span className={`relative w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0 ${
                          complete ? 'bg-neutral-100 text-neutral-400' : active ? 'bg-accent-50 text-black' : 'bg-neutral-50 text-neutral-400'
                        }`}>
                          {categoryIcons[cat.id]}
                          {complete && (
                            <span className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-black flex items-center justify-center">
                              <CheckIcon size={6} />
                            </span>
                          )}
                        </span>
                        <span className="truncate flex-1">{cat.name.replace(/^\d+ – /, '')}</span>
                        <span className="text-[10px] text-neutral-300 flex-shrink-0">{cs.done}/{cs.total}</span>
                      </button>
                    );
                  })}
                </nav>

                <div className="mt-8 pt-6 border-t border-neutral-100">
                  <ContactLouis />
                </div>
              </div>
            </aside>

            <main className="flex-1 min-w-0">
              <div className="px-4 sm:px-10 py-8 sm:py-10">
                {globalStats.actions === 0 ? (
                  <div className="text-center py-20 animate-fade-in">
                    <div className="w-16 h-16 rounded-full bg-black flex items-center justify-center mx-auto mb-6">
                      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" className="text-white"><path d="M5 12L10 17L19 7" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                    </div>
                    <h1 className="text-2xl font-bold mb-2">Dossier complet</h1>
                    <p className="text-neutral-400 text-sm max-w-xs mx-auto">Votre conseiller reviendra vers vous rapidement.</p>
                  </div>
                ) : (
                  <>
                    <div className="mb-8 animate-fade-in" key={activeCategory.id}>
                      <div className="flex items-center justify-between mb-1">
                        <h1 className="text-xl font-bold">{activeCategory.name}</h1>
{/* No add button — everything comes from validated profile */}
                      </div>
                      <p className="text-sm text-neutral-400 mb-4">{activeCategory.description}</p>
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-1 bg-neutral-100 rounded-full overflow-hidden">
                          <div className="h-full bg-accent rounded-full transition-all duration-500" style={{ width: `${(stats.done / stats.total) * 100}%` }} />
                        </div>
                        <span className="text-xs text-neutral-400">{stats.done}/{stats.total}</span>
                      </div>
                    </div>

                    <DocumentList documents={activeCategory.documents} onUpload={handleUpload} onPreview={setPreviewDoc} onReset={handleReset} />

                    <AddDocumentZone activeCategory={activeCategory} onUpload={handleUpload} />

                    <div className="flex items-center justify-between mt-10 pt-6 border-t border-neutral-100">
                      <button onClick={goPrev} disabled={activeCategoryIndex === 0} className={`h-10 px-5 rounded-xl text-sm font-semibold transition-all ${activeCategoryIndex === 0 ? 'text-neutral-300 cursor-not-allowed' : 'text-neutral-500 hover:text-black hover:bg-neutral-50 active:scale-95'}`}>Précédent</button>
                      <button onClick={goNext} disabled={activeCategoryIndex === categories.length - 1 && isComplete(activeCategory)} className={`h-10 px-6 rounded-xl text-sm font-semibold transition-all ${activeCategoryIndex === categories.length - 1 && isComplete(activeCategory) ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed' : 'bg-black text-white hover:bg-neutral-800 active:scale-95'}`}>{stats.actions > 0 ? `${stats.actions} restant${stats.actions > 1 ? 's' : ''} · Continuer` : 'Continuer'}</button>
                    </div>
                  </>
                )}
              </div>
            </main>
          </div>
        </>
      )}

      {/* ═══ PROFIL TAB ═══ */}
      {activeTab === 'profil' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
          <ProfilView profile={profile} setProfile={setProfile as React.Dispatch<React.SetStateAction<UserProfile>>} onValidated={() => setActiveTab('documents')} showToast={showToast} />
        </div>
      )}

      {/* Preview modal */}
      {previewDoc && previewDoc.fileUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4" onClick={() => setPreviewDoc(null)}>
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" />
          <div className="relative bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col animate-scale-in overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-100">
              <div className="min-w-0">
                <p className="text-sm font-semibold truncate">{previewDoc.name}</p>
                <p className="text-xs text-neutral-400 mt-0.5">{previewDoc.person}{previewDoc.date && ` · ${previewDoc.date}`}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <a href={previewDoc.fileUrl} download={previewDoc.fileName}
                  className="h-8 px-3 rounded-lg border border-neutral-200 bg-white text-xs font-semibold text-neutral-600 hover:border-neutral-400 transition-colors inline-flex items-center gap-1.5"
                  onClick={(e) => e.stopPropagation()}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
                  </svg>
                  Télécharger
                </a>
                <button onClick={() => setPreviewDoc(null)} className="w-8 h-8 rounded-lg hover:bg-neutral-100 flex items-center justify-center transition-colors">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto bg-neutral-50 flex items-center justify-center p-4 min-h-[50vh]">
              {previewDoc.fileName?.match(/\.pdf$/i) ? (
                <iframe src={previewDoc.fileUrl} className="w-full h-full min-h-[50vh] rounded-lg border-0" title={previewDoc.name} />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={previewDoc.fileUrl} alt={previewDoc.name} className="max-w-full max-h-[70vh] rounded-lg object-contain" />
              )}
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-fadeIn">
          <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-black text-white text-xs font-medium shadow-lg">
            <svg width="14" height="14" viewBox="0 0 12 12" fill="none"><path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
            {toast}
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══ PROFIL VIEW ═══ */

type ProfileStep = 'identite' | 'famille' | 'enfants' | 'residence' | 'professionnel' | 'patrimoine' | 'projet' | 'validation';
const profileSteps: { id: ProfileStep; label: string }[] = [
  { id: 'identite', label: 'Identité' },
  { id: 'famille', label: 'Situation familiale' },
  { id: 'enfants', label: 'Enfants' },
  { id: 'residence', label: 'Résidence' },
  { id: 'professionnel', label: 'Professionnel' },
  { id: 'patrimoine', label: 'Patrimoine' },
  { id: 'projet', label: 'Projet' },
  { id: 'validation', label: 'Validation' },
];

function ProfilView({ profile, setProfile, onValidated, showToast }: {
  profile: UserProfile;
  setProfile: React.Dispatch<React.SetStateAction<UserProfile>>;
  onValidated: () => void;
  showToast: (msg: string) => void;
}) {
  const [step, setStep] = useState<ProfileStep>('identite');
  const si = profileSteps.findIndex((s) => s.id === step);

  const goN = () => { if (si < profileSteps.length - 1) setStep(profileSteps[si + 1].id); };
  const goP = () => { if (si > 0) setStep(profileSteps[si - 1].id); };

  const update = <K extends keyof UserProfile>(key: K, value: UserProfile[K]) => {
    setProfile(prev => ({ ...prev, [key]: value }));
  };

  const handleValidate = () => {
    update('profileValidated', true);
    showToast('Profil validé — Documents et Statut débloqués');
    onValidated();
  };

  /* ─── VALIDATED: read-only summary view ─── */
  if (profile.profileValidated) {
    return (
      <>
        <div className="mb-8">
          <h1 className="text-xl font-bold mb-1">Mon profil</h1>
          <p className="text-sm text-neutral-400">Informations validées</p>
        </div>

        <div className="rounded-xl bg-neutral-50 border border-neutral-100 px-4 py-3 mb-8 flex items-center gap-3">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-400 flex-shrink-0">
            <circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" />
          </svg>
          <p className="text-xs text-neutral-500">Votre profil a été validé et n&apos;est plus modifiable. Pour toute modification, contactez votre responsable projet.</p>
        </div>

        <div className="space-y-4">
          <SummarySection title="Identité" items={[
            ['Nom', `${profile.civility === 'madame' ? 'Mme' : 'M.'} ${profile.firstName} ${profile.lastName}`],
            ['Date de naissance', profile.birthDate],
            ['Nationalité', profile.nationality],
            ['Téléphone', profile.phone],
            ['Pays de résidence', profile.countryOfResidence],
          ]} />

          <SummarySection title="Situation familiale" items={[
            ['Statut', { celibataire: 'Célibataire', marie: 'Marié(e)', pacse: 'Pacsé(e)', divorce: 'Divorcé(e)', concubin: 'Concubin(e)' }[profile.maritalStatus as string] || '—'],
            ...(profile.matrimonialRegime ? [['Régime', { communaute_legale: 'Communauté légale', separation_biens: 'Séparation de biens', communaute_universelle: 'Communauté universelle', participation_acquets: 'Participation aux acquêts' }[profile.matrimonialRegime] || '']] : []),
            ...(profile.coEmprunteurFirstName ? [['Co-emprunteur', `${profile.coEmprunteurFirstName} ${profile.coEmprunteurLastName}`]] : []),
            ...(profile.hasPensionAlimentaire ? [['Pension alimentaire', `${profile.pensionAmount} €/mois`]] : []),
          ]} />

          <SummarySection title="Enfants" items={
            profile.children.length > 0
              ? profile.children.map((c, i) => [`Enfant ${i + 1}`, `${c.firstName} — ${c.birthDate}`])
              : [['', 'Aucun enfant à charge']]
          } />

          <SummarySection title="Résidence" items={[
            ['Adresse', `${profile.address}, ${profile.postalCode} ${profile.city}, ${profile.country}`],
            ['Statut', profile.housingStatus === 'proprietaire' ? 'Propriétaire' : 'Locataire'],
            ...(profile.hasLoanRP && profile.loanDetailsRP ? [['Prêt RP', `${profile.loanDetailsRP.monthlyPayment} €/mois — ${profile.loanDetailsRP.bankName}`]] : []),
          ]} />

          <SummarySection title="Professionnel" items={[
            ['Statut', { salarie_cdi: 'Salarié CDI', salarie_cdd: 'Salarié CDD', fonctionnaire: 'Fonctionnaire', independant: 'Indépendant', dirigeant: 'Dirigeant' }[profile.professionalStatus as string] || '—'],
            ['Profession', profile.profession],
            ['Entreprise', profile.company],
            ['Fréquence de paie', profile.payFrequency === 'bi_weekly' ? 'Bi-mensuel' : 'Mensuel'],
            ...(profile.hasBonus ? [['Bonus / primes', 'Oui']] : []),
            ...(profile.isDirigeant ? [['Société (dirigeant)', profile.dirigeantCompanyName || '—']] : []),
            ...(profile.isUS ? [['Résident fiscal US', 'Oui']] : []),
          ]} />

          {profile.realEstateProperties.length > 0 && (
            <SummarySection title={`Patrimoine immobilier (${profile.realEstateProperties.length} bien${profile.realEstateProperties.length > 1 ? 's' : ''})`} items={
              profile.realEstateProperties.flatMap((p) => [
                [p.type, p.address],
                ...(p.hasLoan && p.loanDetails ? [['  Prêt', `${p.loanDetails.monthlyPayment} €/mois — ${p.loanDetails.bankName}`]] : []),
                ...(p.viaSociete ? [['  Société', p.societeName || '—']] : []),
              ])
            } />
          )}

          {profile.projects.length > 0 && (
            <SummarySection title={`Projet${profile.projects.length > 1 ? 's' : ''} à financer`} items={
              profile.projects.flatMap((p) => [
                [p.label || p.location, `${p.amount.toLocaleString('fr-FR')} €`],
                ['  Type', { acquisition_residence: 'Acquisition résidence', investissement_locatif: 'Investissement locatif', travaux: 'Travaux' }[p.type as string] || '—'],
                ['  Notaire', p.notaryName],
              ])
            } />
          )}
        </div>

        {/* Consent section */}
        <div className="mt-10 pt-8 border-t border-neutral-100">
          <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider mb-4">Consentement</p>
          <div className="rounded-2xl border border-neutral-100 flex items-center justify-between p-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-accent-50 flex items-center justify-center flex-shrink-0">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 00-3-3.87" /><path d="M16 3.13a4 4 0 010 7.75" /></svg>
              </div>
              <div>
                <p className="text-sm font-semibold">Accès co-emprunteur</p>
                <p className="text-xs text-neutral-400 mt-0.5">Autoriser le co-emprunteur à consulter et déposer des documents · Révocable à tout moment</p>
              </div>
            </div>
            <button onClick={() => update('coEmprunteurAccess', !profile.coEmprunteurAccess)} className="w-[48px] h-[26px] rounded-full cursor-pointer relative transition-colors duration-200 border-none flex-shrink-0" style={{ background: profile.coEmprunteurAccess ? '#000' : '#e5e5e5' }}>
              <div className="w-5 h-5 rounded-full bg-white absolute top-[3px] transition-[left] duration-200" style={{ left: profile.coEmprunteurAccess ? '25px' : '3px', boxShadow: '0 1px 3px rgba(0,0,0,.15)' }} />
            </button>
          </div>
        </div>

        <div className="mt-8">
          <ContactLouis />
        </div>
      </>
    );
  }

  /* ─── NOT VALIDATED: wizard view ─── */
  return (
    <>
      <div className="mb-8">
        <h1 className="text-xl font-bold mb-1">Mon profil</h1>
        <p className="text-sm text-neutral-400">Étape {si + 1} sur {profileSteps.length}</p>
      </div>

      {/* Step navigation */}
      <div className="flex gap-1 mb-8 overflow-x-auto no-scrollbar">
        {profileSteps.map((s, i) => {
          const canClick = i <= si;
          return (
            <button key={s.id} onClick={() => canClick && setStep(s.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                step === s.id ? 'bg-accent-50 text-black' :
                i < si ? 'text-neutral-500 hover:bg-neutral-50 cursor-pointer' :
                'text-neutral-300 cursor-not-allowed'
              }`}>
              {i < si ? <span className="w-4 h-4 rounded-full bg-black flex items-center justify-center flex-shrink-0"><CheckIcon size={8} /></span>
                : step === s.id ? <span className="w-4 h-4 rounded-full bg-black flex-shrink-0" />
                : <span className="w-4 h-4 rounded-full border-[1.5px] border-neutral-200 flex-shrink-0" />}
              {s.label}
            </button>
          );
        })}
      </div>

      {/* Form content */}
      <div className="animate-fade-in" key={step}>

        {/* ─── STEP: IDENTITE ─── */}
        {step === 'identite' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="w-full sm:w-[160px]">
                <PSelect label="Civilité" value={profile.civility} onChange={(v) => update('civility', v as Civility)} options={[{ value: 'monsieur', label: 'Monsieur' }, { value: 'madame', label: 'Madame' }]} />
              </div>
              <div className="flex-1"><PInput label="Prénom" value={profile.firstName} onChange={(v) => update('firstName', v)} /></div>
              <div className="flex-1"><PInput label="Nom" value={profile.lastName} onChange={(v) => update('lastName', v)} /></div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1"><PInput label="Date de naissance" value={profile.birthDate} onChange={(v) => update('birthDate', v)} placeholder="jj/mm/aaaa" /></div>
              <div className="flex-1"><PInput label="Nationalité" value={profile.nationality} onChange={(v) => update('nationality', v)} placeholder="Ex: Française" /></div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1"><PInput label="Email" value={profile.email} readOnly /></div>
              <div className="flex-1"><PInput label="Téléphone" value={profile.phone} onChange={(v) => update('phone', v)} placeholder="+33 6 12 34 56 78" /></div>
              <div className="flex-1"><PInput label="Pays de résidence" value={profile.countryOfResidence} onChange={(v) => update('countryOfResidence', v)} placeholder="Ex: États-Unis" /></div>
            </div>
          </div>
        )}

        {/* ─── STEP: FAMILLE ─── */}
        {step === 'famille' && (
          <div className="space-y-6">
            <div>
              <p className="text-xs font-medium text-neutral-500 mb-3 uppercase tracking-wider">Statut matrimonial</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {([
                  { value: 'celibataire', label: 'Célibataire' },
                  { value: 'marie', label: 'Marié(e)' },
                  { value: 'pacse', label: 'Pacsé(e)' },
                  { value: 'divorce', label: 'Divorcé(e)' },
                  { value: 'concubin', label: 'Concubin(e)' },
                ] as { value: MaritalStatus; label: string }[]).map((opt) => (
                  <RadioCard key={opt.value} selected={profile.maritalStatus === opt.value} label={opt.label}
                    onClick={() => update('maritalStatus', opt.value)} />
                ))}
              </div>
            </div>

            {(profile.maritalStatus === 'marie') && (
              <div className="animate-fadeIn">
                <PSelect label="Régime matrimonial" value={profile.matrimonialRegime || ''} onChange={(v) => update('matrimonialRegime', v as MatrimonialRegime)}
                  options={[
                    { value: 'communaute_legale', label: 'Communauté légale' },
                    { value: 'separation_biens', label: 'Séparation de biens' },
                    { value: 'communaute_universelle', label: 'Communauté universelle' },
                    { value: 'participation_acquets', label: 'Participation aux acquêts' },
                  ]} />
              </div>
            )}

            {profile.maritalStatus && profile.maritalStatus !== 'celibataire' && (
              <div className="animate-fadeIn space-y-4">
                <div>
                  <PSelect label="Relation avec le co-emprunteur" value={profile.coEmprunteurRelation || ''} onChange={(v) => update('coEmprunteurRelation', v as CoEmprunteurRelation)}
                    options={[
                      { value: 'conjoint', label: 'Conjoint(e)' },
                      { value: 'partenaire_pacs', label: 'Partenaire PACS' },
                      { value: 'concubin', label: 'Concubin(e)' },
                      { value: 'frere_soeur', label: 'Frère / Soeur' },
                      { value: 'parent_enfant', label: 'Parent / Enfant' },
                      { value: 'associe', label: 'Associé(e)' },
                      { value: 'ami', label: 'Ami(e)' },
                      { value: 'autre', label: 'Autre' },
                    ]} />
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1"><PInput label="Prénom du co-emprunteur" value={profile.coEmprunteurFirstName || ''} onChange={(v) => update('coEmprunteurFirstName', v)} /></div>
                  <div className="flex-1"><PInput label="Nom du co-emprunteur" value={profile.coEmprunteurLastName || ''} onChange={(v) => update('coEmprunteurLastName', v)} /></div>
                </div>
              </div>
            )}

            {profile.maritalStatus === 'divorce' && (
              <div className="animate-fadeIn space-y-4 rounded-2xl border border-neutral-100 p-5">
                <ToggleRow label="Pension alimentaire versée" checked={profile.hasPensionAlimentaire || false} onChange={(v) => update('hasPensionAlimentaire', v)} />
                {profile.hasPensionAlimentaire && (
                  <div className="animate-fadeIn">
                    <PInput label="Montant mensuel (€)" value={profile.pensionAmount?.toString() || ''} onChange={(v) => update('pensionAmount', Number(v) || 0)} />
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ─── STEP: ENFANTS ─── */}
        {step === 'enfants' && (
          <div>
            {profile.children.length === 0 && (
              <div className="rounded-2xl border border-neutral-100 p-6 text-center mb-4">
                <p className="text-sm text-neutral-400 mb-1">Aucun enfant à charge</p>
                <p className="text-xs text-neutral-300">Ajoutez un enfant ou passez à l&apos;étape suivante</p>
              </div>
            )}
            {profile.children.map((child, idx) => (
              <div key={idx} className="rounded-2xl border border-neutral-100 p-5 mb-3">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-sm font-semibold">Enfant {idx + 1}</span>
                  <button onClick={() => update('children', profile.children.filter((_, i) => i !== idx))}
                    className="text-xs font-semibold text-red-500 py-1 px-3 rounded-full border border-red-200 bg-red-50 cursor-pointer">Supprimer</button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <PInput label="Prénom" value={child.firstName} onChange={(v) => {
                    const c = [...profile.children]; c[idx] = { ...c[idx], firstName: v }; update('children', c);
                  }} />
                  <PInput label="Date de naissance" value={child.birthDate} onChange={(v) => {
                    const c = [...profile.children]; c[idx] = { ...c[idx], birthDate: v }; update('children', c);
                  }} placeholder="jj/mm/aaaa" />
                </div>
              </div>
            ))}
            <button onClick={() => update('children', [...profile.children, { firstName: '', birthDate: '' }])}
              className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl border-2 border-dashed border-neutral-200 bg-white text-sm font-semibold cursor-pointer hover:border-neutral-300 transition-colors">+ Ajouter un enfant</button>
          </div>
        )}

        {/* ─── STEP: RESIDENCE ─── */}
        {step === 'residence' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1"><PInput label="Adresse" value={profile.address} onChange={(v) => update('address', v)} /></div>
              <div className="w-full sm:w-[100px]"><PInput label="Code postal" value={profile.postalCode} onChange={(v) => update('postalCode', v)} /></div>
              <div className="w-full sm:w-[160px]"><PInput label="Ville" value={profile.city} onChange={(v) => update('city', v)} /></div>
            </div>
            <PInput label="Pays" value={profile.country} onChange={(v) => update('country', v)} placeholder="Ex: France" />

            <div>
              <p className="text-xs font-medium text-neutral-500 mb-3 uppercase tracking-wider">Statut d&apos;occupation</p>
              <div className="flex gap-3">
                {([
                  { value: 'locataire', label: 'Locataire' },
                  { value: 'proprietaire', label: 'Propriétaire' },
                ] as { value: HousingStatus; label: string }[]).map((opt) => (
                  <RadioCard key={opt.value} selected={profile.housingStatus === opt.value} label={opt.label}
                    onClick={() => update('housingStatus', opt.value)} className="flex-1" />
                ))}
              </div>
            </div>

            {profile.housingStatus === 'proprietaire' && (
              <div className="animate-fadeIn space-y-4 rounded-2xl border border-neutral-100 p-5">
                <ToggleRow label="Prêt en cours sur la résidence" checked={profile.hasLoanRP} onChange={(v) => update('hasLoanRP', v)} />
                {profile.hasLoanRP && (
                  <div className="animate-fadeIn grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <PInput label="Banque" value={profile.loanDetailsRP?.bankName || ''} onChange={(v) => update('loanDetailsRP', { bankName: v, monthlyPayment: profile.loanDetailsRP?.monthlyPayment || 0 })} />
                    <PInput label="Mensualité (€)" value={profile.loanDetailsRP?.monthlyPayment?.toString() || ''} onChange={(v) => update('loanDetailsRP', { bankName: profile.loanDetailsRP?.bankName || '', monthlyPayment: Number(v) || 0 })} />
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ─── STEP: PROFESSIONNEL ─── */}
        {step === 'professionnel' && (
          <div className="space-y-6">
            <div>
              <p className="text-xs font-medium text-neutral-500 mb-3 uppercase tracking-wider">Statut professionnel</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {([
                  { value: 'salarie_cdi', label: 'Salarié CDI' },
                  { value: 'salarie_cdd', label: 'Salarié CDD' },
                  { value: 'fonctionnaire', label: 'Fonctionnaire' },
                  { value: 'independant', label: 'Indépendant' },
                  { value: 'dirigeant', label: 'Dirigeant' },
                ] as { value: ProfessionalStatus; label: string }[]).map((opt) => (
                  <RadioCard key={opt.value} selected={profile.professionalStatus === opt.value} label={opt.label}
                    onClick={() => update('professionalStatus', opt.value)} />
                ))}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1"><PInput label="Profession" value={profile.profession} onChange={(v) => update('profession', v)} placeholder="Ex: Ingénieur" /></div>
              <div className="flex-1"><PInput label="Entreprise" value={profile.company} onChange={(v) => update('company', v)} /></div>
              <div className="flex-1"><PInput label="Pays de travail" value={profile.workCountry} onChange={(v) => update('workCountry', v)} /></div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <PSelect label="Fréquence de paie" value={profile.payFrequency} onChange={(v) => update('payFrequency', v as 'mensuel' | 'bi_weekly')}
                  options={[{ value: 'mensuel', label: 'Mensuel' }, { value: 'bi_weekly', label: 'Bi-mensuel (bi-weekly)' }]} />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-6">
              <ToggleRow label="Bonus / primes" checked={profile.hasBonus} onChange={(v) => update('hasBonus', v)} />
              <ToggleRow label="Résident fiscal US" checked={profile.isUS} onChange={(v) => update('isUS', v)} />
            </div>

            {profile.isUS && (
              <div className="animate-fadeIn rounded-xl bg-amber-50 border border-amber-200 px-4 py-3">
                <p className="text-xs text-amber-700">En tant que résident fiscal US, des documents supplémentaires seront requis (W2, 1099, SSN).</p>
              </div>
            )}

            <ToggleRow label="Également dirigeant / associé d'une société" checked={profile.isDirigeant} onChange={(v) => update('isDirigeant', v)} />

            {profile.isDirigeant && (
              <div className="animate-fadeIn flex flex-col sm:flex-row gap-4">
                <div className="flex-1"><PInput label="Nom de la société" value={profile.dirigeantCompanyName || ''} onChange={(v) => update('dirigeantCompanyName', v)} /></div>
              </div>
            )}
          </div>
        )}

        {/* ─── STEP: PATRIMOINE ─── */}
        {step === 'patrimoine' && (
          <div>
            {profile.realEstateProperties.length === 0 && (
              <div className="rounded-2xl border border-neutral-100 p-6 text-center mb-4">
                <p className="text-sm text-neutral-400 mb-1">Aucun bien immobilier</p>
                <p className="text-xs text-neutral-300">Ajoutez un bien ou passez à l&apos;étape suivante</p>
              </div>
            )}
            {profile.realEstateProperties.map((prop, idx) => (
              <PropertyCard key={prop.id} property={prop} index={idx}
                onChange={(p) => { const arr = [...profile.realEstateProperties]; arr[idx] = p; update('realEstateProperties', arr); }}
                onRemove={() => update('realEstateProperties', profile.realEstateProperties.filter((_, i) => i !== idx))} />
            ))}
            <button onClick={() => update('realEstateProperties', [...profile.realEstateProperties, {
              id: `prop-${Date.now()}`, address: '', type: 'Appartement', usage: 'loue', hasLoan: false, viaSociete: false,
            }])}
              className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl border-2 border-dashed border-neutral-200 bg-white text-sm font-semibold cursor-pointer hover:border-neutral-300 transition-colors mt-4">+ Ajouter un bien</button>
          </div>
        )}

        {/* ─── STEP: PROJET ─── */}
        {step === 'projet' && (
          <div>
            {profile.projects.length === 0 && (
              <div className="rounded-2xl border border-neutral-100 p-6 text-center mb-4">
                <p className="text-sm text-neutral-400 mb-1">Aucun projet à financer</p>
                <p className="text-xs text-neutral-300">Ajoutez votre projet immobilier</p>
              </div>
            )}
            {profile.projects.map((proj, idx) => (
              <ProjectCard key={proj.id} project={proj} index={idx}
                onChange={(p) => { const arr = [...profile.projects]; arr[idx] = p; update('projects', arr); }}
                onRemove={() => update('projects', profile.projects.filter((_, i) => i !== idx))} />
            ))}
            <button onClick={() => update('projects', [...profile.projects, {
              id: `proj-${Date.now()}`, type: '', label: '', amount: 0, location: '',
              notaryName: '', isInvestissementLocatif: false, hasDevisTravaux: false,
            }])}
              className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl border-2 border-dashed border-neutral-200 bg-white text-sm font-semibold cursor-pointer hover:border-neutral-300 transition-colors mt-4">+ Ajouter un projet</button>
          </div>
        )}

        {/* ─── STEP: VALIDATION ─── */}
        {step === 'validation' && (
          <div className="space-y-6">
            {!profile.profileValidated && (
              <div className="rounded-xl bg-accent-50 border border-accent-light p-4 mb-2">
                <p className="text-sm font-semibold mb-1">Vérifiez vos informations</p>
                <p className="text-xs text-neutral-600">Une fois validé, votre profil sera verrouillé et vous pourrez accéder aux onglets Documents et Statut.</p>
              </div>
            )}

            <SummarySection title="Identité" items={[
              ['Nom', `${profile.civility === 'madame' ? 'Mme' : 'M.'} ${profile.firstName} ${profile.lastName}`],
              ['Date de naissance', profile.birthDate],
              ['Nationalité', profile.nationality],
              ['Téléphone', profile.phone],
              ['Pays de résidence', profile.countryOfResidence],
            ]} />

            <SummarySection title="Situation familiale" items={[
              ['Statut', { celibataire: 'Célibataire', marie: 'Marié(e)', pacse: 'Pacsé(e)', divorce: 'Divorcé(e)', concubin: 'Concubin(e)' }[profile.maritalStatus as string] || '—'],
              ...(profile.matrimonialRegime ? [['Régime', { communaute_legale: 'Communauté légale', separation_biens: 'Séparation de biens', communaute_universelle: 'Communauté universelle', participation_acquets: 'Participation aux acquêts' }[profile.matrimonialRegime] || '']] : []),
              ...(profile.coEmprunteurFirstName ? [['Co-emprunteur', `${profile.coEmprunteurFirstName} ${profile.coEmprunteurLastName}`]] : []),
            ]} />

            <SummarySection title="Enfants" items={
              profile.children.length > 0
                ? profile.children.map((c, i) => [`Enfant ${i + 1}`, `${c.firstName} — ${c.birthDate}`])
                : [['', 'Aucun enfant à charge']]
            } />

            <SummarySection title="Résidence" items={[
              ['Adresse', `${profile.address}, ${profile.postalCode} ${profile.city}, ${profile.country}`],
              ['Statut', profile.housingStatus === 'proprietaire' ? 'Propriétaire' : 'Locataire'],
              ...(profile.hasLoanRP && profile.loanDetailsRP ? [['Prêt RP', `${profile.loanDetailsRP.monthlyPayment} €/mois — ${profile.loanDetailsRP.bankName}`]] : []),
            ]} />

            <SummarySection title="Professionnel" items={[
              ['Statut', { salarie_cdi: 'Salarié CDI', salarie_cdd: 'Salarié CDD', fonctionnaire: 'Fonctionnaire', independant: 'Indépendant', dirigeant: 'Dirigeant' }[profile.professionalStatus as string] || '—'],
              ['Profession', profile.profession],
              ['Entreprise', profile.company],
              ['Fréquence de paie', profile.payFrequency === 'bi_weekly' ? 'Bi-mensuel' : 'Mensuel'],
              ...(profile.hasBonus ? [['Bonus / primes', 'Oui']] : []),
              ...(profile.isDirigeant ? [['Société (dirigeant)', profile.dirigeantCompanyName || '—']] : []),
              ...(profile.isUS ? [['Résident fiscal US', 'Oui']] : []),
            ]} />

            {profile.realEstateProperties.length > 0 && (
              <SummarySection title={`Patrimoine immobilier (${profile.realEstateProperties.length} bien${profile.realEstateProperties.length > 1 ? 's' : ''})`} items={
                profile.realEstateProperties.map((p) => [p.type, `${p.address}${p.viaSociete ? ` — via ${p.societeName}` : ''}`])
              } />
            )}

            {profile.projects.length > 0 && (
              <SummarySection title={`Projet${profile.projects.length > 1 ? 's' : ''} à financer`} items={
                profile.projects.map((p) => [p.label || p.location, `${p.amount.toLocaleString('fr-FR')} € — ${p.notaryName}`])
              } />
            )}

            {!profile.profileValidated && (
              <button onClick={handleValidate}
                className="w-full h-12 bg-black text-white text-sm font-semibold rounded-xl hover:bg-neutral-800 active:scale-[0.98] transition-all mt-4">
                Valider mon profil
              </button>
            )}
          </div>
        )}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between mt-10 pt-6 border-t border-neutral-100">
        <button onClick={goP} disabled={si === 0} className={`h-10 px-5 rounded-xl text-sm font-semibold transition-all ${si === 0 ? 'text-neutral-300 cursor-not-allowed' : 'text-neutral-500 hover:text-black hover:bg-neutral-50 active:scale-95'}`}>Précédent</button>
        {step !== 'validation' && (
          <button onClick={goN} className="h-10 px-6 rounded-xl text-sm font-semibold bg-black text-white hover:bg-neutral-800 active:scale-95 transition-all">Continuer</button>
        )}
      </div>

      {/* Consent section — always visible, separate from wizard */}
      <div className="mt-10 pt-8 border-t border-neutral-100">
        <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider mb-4">Consentement</p>
        <div className="rounded-2xl border border-neutral-100 flex items-center justify-between p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-accent-50 flex items-center justify-center flex-shrink-0">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 00-3-3.87" /><path d="M16 3.13a4 4 0 010 7.75" /></svg>
            </div>
            <div>
              <p className="text-sm font-semibold">Accès co-emprunteur</p>
              <p className="text-xs text-neutral-400 mt-0.5">Autoriser le co-emprunteur à consulter et déposer des documents · Révocable à tout moment</p>
            </div>
          </div>
          <button onClick={() => update('coEmprunteurAccess', !profile.coEmprunteurAccess)} className="w-[48px] h-[26px] rounded-full cursor-pointer relative transition-colors duration-200 border-none flex-shrink-0" style={{ background: profile.coEmprunteurAccess ? '#000' : '#e5e5e5' }}>
            <div className="w-5 h-5 rounded-full bg-white absolute top-[3px] transition-[left] duration-200" style={{ left: profile.coEmprunteurAccess ? '25px' : '3px', boxShadow: '0 1px 3px rgba(0,0,0,.15)' }} />
          </button>
        </div>
      </div>

      <div className="mt-8">
        <ContactLouis />
      </div>
    </>
  );
}

/* ═══ Sub-components ═══ */

function PropertyCard({ property: p, index, onChange, onRemove }: { property: RealEstateProperty; index: number; onChange: (p: RealEstateProperty) => void; onRemove: () => void }) {
  const upd = (partial: Partial<RealEstateProperty>) => onChange({ ...p, ...partial });
  return (
    <div className="rounded-2xl border border-neutral-100 p-5 mb-3">
      <div className="flex justify-between items-center mb-4">
        <span className="text-sm font-semibold">Bien {index + 1}</span>
        <button onClick={onRemove} className="text-xs font-semibold text-red-500 py-1 px-3 rounded-full border border-red-200 bg-red-50 cursor-pointer">Supprimer</button>
      </div>
      <div className="space-y-3">
        <PInput label="Adresse" value={p.address} onChange={(v) => upd({ address: v })} />
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            <PSelect label="Type" value={p.type} onChange={(v) => upd({ type: v })} options={[
              { value: 'Appartement', label: 'Appartement' }, { value: 'Maison', label: 'Maison' },
              { value: 'Immeuble', label: 'Immeuble' }, { value: 'Terrain', label: 'Terrain' }, { value: 'Local commercial', label: 'Local commercial' },
            ]} />
          </div>
          <div className="flex-1">
            <p className="text-xs font-medium text-neutral-500 mb-1.5 uppercase tracking-wider">Usage</p>
            <div className="flex gap-2">
              <RadioCard selected={p.usage === 'loue'} label="Loué" onClick={() => upd({ usage: 'loue' })} className="flex-1" />
              <RadioCard selected={p.usage === 'occupe'} label="Occupé" onClick={() => upd({ usage: 'occupe' })} className="flex-1" />
            </div>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row gap-4">
          <ToggleRow label="Prêt en cours" checked={p.hasLoan} onChange={(v) => upd({ hasLoan: v })} />
          <ToggleRow label="Via une société (SCI...)" checked={p.viaSociete} onChange={(v) => upd({ viaSociete: v })} />
        </div>
        {p.hasLoan && (
          <div className="animate-fadeIn grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <PInput label="Banque" value={p.loanDetails?.bankName || ''} onChange={(v) => upd({ loanDetails: { bankName: v, monthlyPayment: p.loanDetails?.monthlyPayment || 0 } })} />
            <PInput label="Mensualité (€)" value={p.loanDetails?.monthlyPayment?.toString() || ''} onChange={(v) => upd({ loanDetails: { bankName: p.loanDetails?.bankName || '', monthlyPayment: Number(v) || 0 } })} />
          </div>
        )}
        {p.viaSociete && (
          <div className="animate-fadeIn">
            <PInput label="Nom de la société" value={p.societeName || ''} onChange={(v) => upd({ societeName: v })} />
          </div>
        )}
      </div>
    </div>
  );
}

function ProjectCard({ project: p, index, onChange, onRemove }: { project: ProjectToFinance; index: number; onChange: (p: ProjectToFinance) => void; onRemove: () => void }) {
  const upd = (partial: Partial<ProjectToFinance>) => onChange({ ...p, ...partial });
  return (
    <div className="rounded-2xl border border-neutral-100 p-5 mb-3">
      <div className="flex justify-between items-center mb-4">
        <span className="text-sm font-semibold">Projet {index + 1}</span>
        <button onClick={onRemove} className="text-xs font-semibold text-red-500 py-1 px-3 rounded-full border border-red-200 bg-red-50 cursor-pointer">Supprimer</button>
      </div>
      <div className="space-y-4">
        <PInput label="Nom du projet" value={p.label} onChange={(v) => upd({ label: v })} placeholder="Ex: Appartement Lyon 6e" />
        <div>
          <p className="text-xs font-medium text-neutral-500 mb-3 uppercase tracking-wider">Type de projet</p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {([
              { value: 'acquisition_residence', label: 'Acquisition résidence' },
              { value: 'investissement_locatif', label: 'Investissement locatif' },
              { value: 'travaux', label: 'Travaux' },
            ] as { value: ProjectType; label: string }[]).map((opt) => (
              <RadioCard key={opt.value} selected={p.type === opt.value} label={opt.label}
                onClick={() => upd({ type: opt.value, isInvestissementLocatif: opt.value === 'investissement_locatif' })} />
            ))}
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <PInput label="Montant (€)" value={p.amount ? p.amount.toString() : ''} onChange={(v) => upd({ amount: Number(v) || 0 })} />
          <PInput label="Localisation" value={p.location} onChange={(v) => upd({ location: v })} />
          <PInput label="Nom du notaire" value={p.notaryName} onChange={(v) => upd({ notaryName: v })} placeholder="Me. Dupont" />
        </div>
        <ToggleRow label="Devis travaux prévu" checked={p.hasDevisTravaux} onChange={(v) => upd({ hasDevisTravaux: v })} />
      </div>
    </div>
  );
}

function SummarySection({ title, items }: { title: string; items: string[][] }) {
  return (
    <div className="rounded-2xl border border-neutral-100 p-5">
      <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider mb-3">{title}</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-xs">
        {items.map(([label, value], i) => (
          <div key={i} className="flex justify-between py-1">
            <span className="text-neutral-400">{label}</span>
            <span className="text-black font-medium text-right">{value || '—'}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══ Document list with group support ═══ */

function DocumentList({ documents, onUpload, onPreview, onReset }: {
  documents: DocumentItem[];
  onUpload: (docId: string, fileName: string, fileUrl: string) => void;
  onPreview: (doc: DocumentItem) => void;
  onReset: (docId: string) => void;
}) {
  const hasGroups = documents.some((d) => d.group);

  if (!hasGroups) {
    const needsAction = documents.filter((d) => d.status === 'missing' || d.status === 'rejected');
    const done = documents.filter((d) => d.status !== 'missing' && d.status !== 'rejected');
    return (
      <div className="space-y-3">
        {needsAction.map((doc, i) => <DocumentSlot key={doc.id} document={doc} index={i} onUpload={onUpload} onPreview={onPreview} onReset={onReset} />)}
        {needsAction.length > 0 && done.length > 0 && (
          <div className="flex items-center gap-3 py-2">
            <div className="flex-1 h-px bg-neutral-100" /><span className="text-[10px] uppercase tracking-widest text-neutral-300 font-semibold">Documents téléchargés</span><div className="flex-1 h-px bg-neutral-100" />
          </div>
        )}
        {done.map((doc, i) => <DocumentSlot key={doc.id} document={doc} index={i + needsAction.length} onUpload={onUpload} onPreview={onPreview} onReset={onReset} />)}
      </div>
    );
  }

  const groups: { name: string; docs: DocumentItem[] }[] = [];
  const ungrouped: DocumentItem[] = [];
  for (const doc of documents) {
    if (doc.group) {
      let g = groups.find((gr) => gr.name === doc.group);
      if (!g) { g = { name: doc.group, docs: [] }; groups.push(g); }
      g.docs.push(doc);
    } else {
      ungrouped.push(doc);
    }
  }

  const sortedGroups = [...groups].sort((a, b) => {
    const aOk = a.docs.every((d) => d.status !== 'missing' && d.status !== 'rejected');
    const bOk = b.docs.every((d) => d.status !== 'missing' && d.status !== 'rejected');
    return aOk === bOk ? 0 : aOk ? 1 : -1;
  });

  return (
    <div className="space-y-3">
      {sortedGroups.map((group) => (
        <DocumentGroup key={group.name} group={group} onUpload={onUpload} onPreview={onPreview} onReset={onReset} />
      ))}
      {ungrouped.length > 0 && ungrouped.map((doc, i) => (
        <DocumentSlot key={doc.id} document={doc} index={i} onUpload={onUpload} onPreview={onPreview} onReset={onReset} />
      ))}
    </div>
  );
}

function DocumentGroup({ group, onUpload, onPreview, onReset }: {
  group: { name: string; docs: DocumentItem[] };
  onUpload: (docId: string, fileName: string, fileUrl: string) => void;
  onPreview: (doc: DocumentItem) => void;
  onReset: (docId: string) => void;
}) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const uploaded = group.docs.filter((d) => d.status !== 'missing' && d.status !== 'rejected');
  const remaining = group.docs.filter((d) => d.status === 'missing' || d.status === 'rejected');
  const done = uploaded.length;
  const total = group.docs.length;
  const complete = done === total;

  const handleFiles = async (files: FileList) => {
    setIsUploading(true);
    const slots = remaining.slice(0, files.length);
    for (let i = 0; i < slots.length; i++) {
      const url = URL.createObjectURL(files[i]);
      await new Promise((r) => setTimeout(r, 300));
      onUpload(slots[i].id, files[i].name, url);
    }
    setIsUploading(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files.length > 0) handleFiles(e.dataTransfer.files);
  };

  return (
    <div className={`rounded-xl border transition-all ${complete ? 'border-neutral-100' : 'border-neutral-200 bg-white'}`}
      style={complete ? { opacity: 0.5 } : undefined}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${complete ? 'bg-black' : 'bg-accent-50'}`}>
            {complete ? <CheckIcon size={8} /> : (
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-black"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" /><polyline points="14 2 14 8 20 8" /></svg>
            )}
          </div>
          <div>
            <p className={`text-sm font-semibold ${complete ? 'text-neutral-400' : 'text-black'}`}>{group.name}</p>
            {remaining.length > 0 && remaining.some((d) => d.status === 'rejected') && (
              <p className="text-xs text-red-500 mt-0.5">{remaining.filter((d) => d.status === 'rejected').map((d) => d.rejectionReason).join(' · ')}</p>
            )}
          </div>
        </div>
        <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${complete ? 'bg-neutral-100 text-neutral-400' : done > 0 ? 'bg-accent-50 text-black' : 'bg-neutral-100 text-neutral-500'}`}>{done}/{total}</span>
      </div>

      {/* Drop zone — only if not complete */}
      {!complete && (
        <div className="px-4 pb-4">
          <div
            className={`relative rounded-xl border-2 border-dashed p-4 transition-all text-center ${
              isDragging ? 'border-accent-dark bg-accent-50 scale-[1.01]' : 'border-neutral-200 hover:border-neutral-300'
            }`}
            onDrop={handleDrop}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
          >
            {isUploading ? (
              <div className="flex items-center justify-center gap-2 py-1">
                <svg className="animate-spin h-4 w-4 text-neutral-400" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2.5" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                <span className="text-xs text-neutral-400">Envoi en cours...</span>
              </div>
            ) : (
              <button onClick={() => fileInputRef.current?.click()} className="w-full bg-transparent border-none cursor-pointer">
                <p className="text-xs font-semibold text-neutral-500">
                  {isDragging ? 'Déposez vos fichiers' : `Déposer ${remaining.length} fichier${remaining.length > 1 ? 's' : ''}`}
                </p>
                <p className="text-[11px] text-neutral-300 mt-0.5">Glissez-déposez ou cliquez · PDF, JPG, PNG</p>
              </button>
            )}
            <input ref={fileInputRef} type="file" accept=".pdf,.jpg,.jpeg,.png" multiple onChange={(e) => { if (e.target.files) handleFiles(e.target.files); }} className="hidden" />
          </div>
        </div>
      )}

      {/* Uploaded files — compact list */}
      {uploaded.length > 0 && (
        <div className={`px-4 ${complete ? 'pb-3' : 'pb-4'} ${!complete ? 'pt-0' : ''}`}>
          <div className="space-y-0.5">
            {uploaded.map((doc) => (
              <GroupFileRow key={doc.id} doc={doc} onPreview={onPreview} onReset={onReset} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function GroupFileRow({ doc, onPreview, onReset }: { doc: DocumentItem; onPreview: (doc: DocumentItem) => void; onReset: (docId: string) => void }) {
  const [expanded, setExpanded] = useState(false);
  const isValidated = doc.status === 'validated';
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div>
      <button
        onClick={() => isValidated ? setExpanded(!expanded) : onPreview(doc)}
        className="w-full flex items-center justify-between py-2 px-2 rounded-lg hover:bg-neutral-50 transition-colors cursor-pointer bg-transparent border-none text-left"
      >
        <div className="flex items-center gap-2 min-w-0">
          <div className={`w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 ${isValidated ? 'bg-black' : 'bg-accent'}`}>
            {isValidated ? <CheckIcon size={6} /> : (
              <svg width="6" height="6" viewBox="0 0 12 12" fill="none"><path d="M2.5 6L5 8.5L9.5 3.5" stroke="black" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
            )}
          </div>
          <span className="text-xs text-neutral-500 truncate">{doc.name}</span>
          {doc.fileName && <span className="text-[10px] text-neutral-300 truncate">{doc.fileName}</span>}
        </div>
        <span className="text-[10px] text-neutral-300 flex-shrink-0">
          {isValidated ? 'Validé' : doc.status === 'reviewing' ? 'En vérification' : 'Déposé'}
        </span>
      </button>
      {expanded && isValidated && (
        <div className="ml-8 pb-2 pt-1 flex items-center gap-3 animate-fadeIn">
          <button onClick={() => onPreview(doc)} className="text-xs text-neutral-500 hover:text-black transition-colors cursor-pointer bg-transparent border-none underline underline-offset-2">
            Voir le document
          </button>
          <button onClick={() => { onReset(doc.id); setExpanded(false); }} className="text-xs text-red-500 hover:text-red-700 transition-colors cursor-pointer bg-transparent border-none underline underline-offset-2">
            Supprimer et remplacer
          </button>
          <input ref={fileRef} type="file" accept=".pdf,.jpg,.jpeg,.png" className="hidden" />
        </div>
      )}
    </div>
  );
}

/* ═══ Smart upload zone ═══ */

const commonDocsByCategory: Record<string, string[]> = {
  f0: ['Mandat de courtage', 'Lettre de mission'],
  f1: ['CNI', 'Passeport', 'Titre de séjour', 'Permis de conduire'],
  f2: ['Acte de mariage', 'Livret de famille', 'Acte de naissance', 'Jugement de divorce'],
  f3: ['Justificatif de domicile', 'Bail de location', 'Attestation hébergement', 'Quittance de loyer'],
  f4: ['Contrat de travail CDI', 'Contrat de travail CDD', 'Avenant au contrat', 'Attestation employeur'],
  f5: ['Bulletin de salaire', 'Attestation de revenus', 'Relevé Pôle Emploi'],
  f6: ['Avis d\'imposition', 'Déclaration de revenus', 'Avis de taxe foncière'],
  f7: ['Relevé de compte courant', 'RIB'],
  f8: ['Relevé Livret A', 'Relevé PEL', 'Relevé assurance vie', 'Relevé PEA'],
  f9: ['Titre de propriété', 'Taxe foncière', 'Tableau d\'amortissement', 'Estimation immobilière'],
  f10: ['Compromis de vente', 'Plan de financement', 'Diagnostics immobiliers', 'Devis travaux', 'Permis de construire'],
};

function AddDocumentZone({ activeCategory, onUpload }: { activeCategory: Category; onUpload: (docId: string, fileName: string, fileUrl: string) => void }) {
  const [open, setOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const [selectedType, setSelectedType] = useState<string | null>(null);

  const existingNames = activeCategory.documents.map((d) => d.name);
  const suggestions = (commonDocsByCategory[activeCategory.id] || []).filter((name) => !existingNames.includes(name));

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && selectedType) {
      const url = URL.createObjectURL(file);
      onUpload(selectedType, file.name, url);
      setOpen(false);
      setSelectedType(null);
    }
  };

  const pickAndUpload = (type: string) => {
    setSelectedType(type);
    fileRef.current?.click();
  };

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="mt-6 w-full border-2 border-dashed border-neutral-200 rounded-2xl p-5 flex items-center justify-center gap-3 cursor-pointer hover:border-neutral-300 transition-colors bg-transparent">
        <div className="w-8 h-8 rounded-full bg-accent-50 flex items-center justify-center">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
        </div>
        <span className="text-sm font-semibold">Ajouter un document</span>
      </button>
    );
  }

  return (
    <div className="mt-6 rounded-2xl border border-neutral-200 p-5">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-semibold">Quel document souhaitez-vous ajouter ?</p>
        <button onClick={() => setOpen(false)} className="text-xs text-neutral-400 hover:text-black transition-colors cursor-pointer bg-transparent border-none">Fermer</button>
      </div>
      {suggestions.length > 0 && (
        <div className="space-y-1.5 mb-4">
          {suggestions.map((name) => (
            <button key={name} onClick={() => pickAndUpload(name)}
              className="w-full flex items-center gap-3 p-3 rounded-xl border border-neutral-100 hover:border-neutral-200 transition-colors cursor-pointer bg-transparent text-left group">
              <div className="w-6 h-6 rounded-full bg-accent-50 flex items-center justify-center flex-shrink-0">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" /><polyline points="14 2 14 8 20 8" /></svg>
              </div>
              <span className="text-sm flex-1">{name}</span>
              <span className="text-xs text-neutral-300 group-hover:text-black transition-colors">Déposer</span>
            </button>
          ))}
        </div>
      )}
      <button onClick={() => pickAndUpload('annexe-' + Date.now())}
        className="w-full flex items-center justify-center gap-2 p-3 rounded-xl border-2 border-dashed border-neutral-200 text-sm font-semibold cursor-pointer hover:border-neutral-300 transition-colors bg-transparent">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
        Document annexe
      </button>
      <p className="text-[11px] text-neutral-300 text-center mt-2">PDF, JPG, PNG</p>
      <input ref={fileRef} type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileSelected} className="hidden" />
    </div>
  );
}

/* ═══ Shared UI components ═══ */

function ContactLouis() {
  return (
    <div className="space-y-3">
      <GDPRBadge />
      <p className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">Responsable projet</p>
      <a href="https://wa.me/33780392039" target="_blank" rel="noopener noreferrer"
        className="flex items-center gap-3 rounded-2xl border border-neutral-100 p-4 hover:border-neutral-200 transition-colors no-underline group">
        <div className="relative flex-shrink-0">
          <img src="/56BVrJgZ9tFYU0xCYrw5VaaDFeg (1).avif" alt="Louis Felix Salley" className="w-10 h-10 rounded-full object-cover" />
          <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-white flex items-center justify-center shadow-sm">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-black">Louis Felix Salley</p>
          <p className="text-xs text-neutral-400">Contacter sur WhatsApp</p>
        </div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-neutral-300 group-hover:text-black transition-colors flex-shrink-0"><polyline points="9 18 15 12 9 6" /></svg>
      </a>
    </div>
  );
}

function GDPRBadge() {
  return (
    <div className="flex items-center gap-2">
      <svg width="18" height="13" viewBox="0 0 20 14" fill="none" className="flex-shrink-0">
        <rect width="20" height="14" rx="2" fill="#003399" />
        {[0,1,2,3,4,5,6,7,8,9,10,11].map((i) => {
          const angle = (i * 30 - 90) * (Math.PI / 180);
          const cx = 10 + 4.5 * Math.cos(angle);
          const cy = 7 + 4.5 * Math.sin(angle);
          return <circle key={i} cx={cx} cy={cy} r="0.7" fill="#FFCC00" />;
        })}
      </svg>
      <span className="text-[11px] text-neutral-400">Hébergé en France · RGPD</span>
    </div>
  );
}

function PInput({ label, value, onChange, placeholder, readOnly }: {
  label: string; value: string; onChange?: (val: string) => void; placeholder?: string; readOnly?: boolean;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-neutral-500 mb-1.5 uppercase tracking-wider">{label}</label>
      <input type="text" value={value} onChange={(e) => onChange?.(e.target.value)}
        placeholder={placeholder} readOnly={readOnly}
        className={`w-full h-10 px-3 rounded-xl border border-neutral-200 bg-white text-sm placeholder:text-neutral-300 focus:outline-none focus:border-black focus:ring-1 focus:ring-black transition-all ${readOnly ? 'bg-neutral-50 text-neutral-400 cursor-not-allowed' : ''}`} />
    </div>
  );
}

function PSelect({ label, value, onChange, options }: {
  label: string; value: string; onChange: (val: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-neutral-500 mb-1.5 uppercase tracking-wider">{label}</label>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full h-10 px-3 rounded-xl border border-neutral-200 bg-white text-sm appearance-none cursor-pointer focus:outline-none focus:border-black focus:ring-1 focus:ring-black transition-all bg-no-repeat bg-[right_12px_center]"
        style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='10' height='6' viewBox='0 0 10 6' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%236B7280'/%3E%3C/svg%3E\")" }}>
        <option value="">—</option>
        {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function RadioCard({ selected, label, onClick, className = '' }: { selected: boolean; label: string; onClick: () => void; className?: string }) {
  return (
    <button onClick={onClick}
      className={`flex items-center justify-center gap-2 p-3 rounded-xl text-sm font-medium cursor-pointer transition-all ${
        selected ? 'border-2 border-black bg-neutral-50 text-black' : 'border border-neutral-200 bg-white text-neutral-400'
      } ${className}`}>
      <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${selected ? 'border-black' : 'border-neutral-300'}`}>
        {selected && <div className="w-[6px] h-[6px] rounded-full bg-black" />}
      </div>
      {label}
    </button>
  );
}

function ToggleRow({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm text-neutral-600">{label}</span>
      <button onClick={() => onChange(!checked)} className="w-[44px] h-[24px] rounded-full cursor-pointer relative transition-colors duration-200 border-none flex-shrink-0" style={{ background: checked ? '#000' : '#e5e5e5' }}>
        <div className="w-[18px] h-[18px] rounded-full bg-white absolute top-[3px] transition-[left] duration-200" style={{ left: checked ? '23px' : '3px', boxShadow: '0 1px 3px rgba(0,0,0,.15)' }} />
      </button>
    </div>
  );
}
