import type { Metadata } from 'next';
import { GeistSans } from 'geist/font/sans';
import './globals.css';

export const metadata: Metadata = {
  title: 'Invexa — Mon dossier',
  description: 'Déposez vos documents pour votre demande de prêt immobilier',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body
        className={`${GeistSans.variable} font-sans font-medium text-black bg-white antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
